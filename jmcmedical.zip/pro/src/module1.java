import javax.swing.ImageIcon;
import java.awt.Image;
import java.sql.*;
import javax.swing.*;
public class module1 extends javax.swing.JFrame {
         Connection con;
         Statement stmt;
    public module1(){
        dbconnection();
        initComponents();
        Image icon=new ImageIcon(this.getClass().getResource("/desktop.png")).getImage();
        this.setIconImage(icon);
        //serlogin.setIconImage("/desktop.png");
        serheadline.setVisible(false);
        serverb.setVisible(true);
        serlogin.setVisible(false);               
    }
    private void dbconnection(){
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
       con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical","root","");
        stmt=con.createStatement();
    }
        catch(ClassNotFoundException | SQLException z){
             JOptionPane.showMessageDialog(this,"Check Datebase Connection..");
             System.exit(0);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        usernamel = new javax.swing.JLabel();
        usernamet = new javax.swing.JTextField();
        passwordl = new javax.swing.JLabel();
        passwordt = new javax.swing.JPasswordField();
        serverb = new javax.swing.JButton();
        serlogin = new javax.swing.JButton();
        empheadline = new javax.swing.JLabel();
        serheadline = new javax.swing.JLabel();
        employeeb = new javax.swing.JButton();
        emplogin = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("JMC MEDICAL");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(java.awt.SystemColor.controlLtHighlight);
        jPanel1.setLayout(null);

        usernamel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        usernamel.setText("UserName :");
        jPanel1.add(usernamel);
        usernamel.setBounds(20, 160, 90, 20);

        usernamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(usernamet);
        usernamet.setBounds(130, 150, 110, 30);

        passwordl.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        passwordl.setText("Password  :");
        jPanel1.add(passwordl);
        passwordl.setBounds(20, 230, 90, 20);

        passwordt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(passwordt);
        passwordt.setBounds(130, 220, 110, 30);

        serverb.setBackground(new java.awt.Color(128, 123, 123));
        serverb.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        serverb.setForeground(new java.awt.Color(255, 255, 255));
        serverb.setText("SERVER");
        serverb.setBorder(null);
        serverb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serverbActionPerformed(evt);
            }
        });
        jPanel1.add(serverb);
        serverb.setBounds(20, 310, 80, 81);

        serlogin.setBackground(new java.awt.Color(128, 123, 123));
        serlogin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        serlogin.setForeground(new java.awt.Color(255, 255, 255));
        serlogin.setText("Login");
        serlogin.setBorder(null);
        serlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serloginActionPerformed(evt);
            }
        });
        jPanel1.add(serlogin);
        serlogin.setBounds(140, 310, 70, 30);

        empheadline.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        empheadline.setText("Employee Login");
        jPanel1.add(empheadline);
        empheadline.setBounds(70, 80, 143, 28);

        serheadline.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        serheadline.setText("Server  Login");
        jPanel1.add(serheadline);
        serheadline.setBounds(80, 80, 120, 25);

        employeeb.setBackground(new java.awt.Color(128, 123, 123));
        employeeb.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        employeeb.setForeground(new java.awt.Color(255, 255, 255));
        employeeb.setText("EMPLOYEE");
        employeeb.setBorder(null);
        employeeb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeebActionPerformed(evt);
            }
        });
        jPanel1.add(employeeb);
        employeeb.setBounds(20, 310, 80, 80);

        emplogin.setBackground(new java.awt.Color(128, 123, 123));
        emplogin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        emplogin.setForeground(new java.awt.Color(255, 255, 255));
        emplogin.setText("Login");
        emplogin.setBorder(null);
        emplogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emploginActionPerformed(evt);
            }
        });
        jPanel1.add(emplogin);
        emplogin.setBounds(140, 310, 70, 30);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(612, 0, 270, 440));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Screenshot (5).png"))); // NOI18N
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 440));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void serloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serloginActionPerformed
        char pf[]=passwordt.getPassword();
        String password=new String(pf);
        int check=0;
        if(usernamet.getText().equals("")||password.equals("")||usernamet.getText().contains(" ")||password.contains(" "))
            JOptionPane.showMessageDialog(this,"Invalid Inputs..");           
        else{
            try {              
                ResultSet rs = stmt.executeQuery("select * from admin");
                while(rs.next()){
                    if(usernamet.getText().equals(rs.getString(1))&&password.equals(rs.getString(2))){
                        check++;
                        module2 ob=new module2();
                        ob.setVisible(true);
                        dispose();
                    }
                }
                if(check==0){
                    JOptionPane.showMessageDialog(this,"Invalid Inputs..");
                    usernamet.setText("");
                    passwordt.setText("");
                }
             } catch (SQLException ex) {
                System.out.println(ex);
                }
        }
    }//GEN-LAST:event_serloginActionPerformed

    private void serverbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serverbActionPerformed
        // TODO add your handling code here:
        serheadline.setVisible(true);
        empheadline.setVisible(false);
        employeeb.setVisible(true);
        serverb.setVisible(false);
        serlogin.setVisible(true);
        emplogin.setVisible(false);
    }//GEN-LAST:event_serverbActionPerformed

    private void employeebActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeebActionPerformed
        // TODO add your handling code here:
       serheadline.setVisible(false);
        empheadline.setVisible(true);
        employeeb.setVisible(false);
        serverb.setVisible(true);
        serlogin.setVisible(false);
        emplogin.setVisible(true);
    }//GEN-LAST:event_employeebActionPerformed

    private void emploginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emploginActionPerformed
         char pf[]=passwordt.getPassword();
        String password=new String(pf);
        int check=0;
        if(usernamet.getText().equals("")||password.equals("")||usernamet.getText().contains(" ")||password.contains(" "))
            JOptionPane.showMessageDialog(this,"Invalid Inputs..");           
        else{
            try {              
                ResultSet rs = stmt.executeQuery("select Eid,username,password from employee");
                while(rs.next()){
                    if(usernamet.getText().equals(rs.getString(2))&&password.equals(rs.getString(3))){
                        check++;
                        module3 ob=new module3(rs.getString(1));
                        ob.setVisible(true);
                        dispose();
                    }
                }
                if(check==0){
                    JOptionPane.showMessageDialog(this,"Invalid Inputs..");
                    usernamet.setText("");
                    passwordt.setText("");
                }
             } catch (SQLException ex) {
                System.out.println(ex);
                }
        }
                      
    }//GEN-LAST:event_emploginActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(module1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(module1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(module1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(module1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new module1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel empheadline;
    private javax.swing.JButton emplogin;
    private javax.swing.JButton employeeb;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel passwordl;
    private javax.swing.JPasswordField passwordt;
    private javax.swing.JLabel serheadline;
    private javax.swing.JButton serlogin;
    private javax.swing.JButton serverb;
    private javax.swing.JLabel usernamel;
    private javax.swing.JTextField usernamet;
    // End of variables declaration//GEN-END:variables
}
