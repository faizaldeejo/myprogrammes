
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author BASHA
 */
public class module3 extends javax.swing.JFrame {

    /**
     * Creates new form module3
     */
    Connection con;
    Statement stmt;
    int purtot;
    DefaultTableModel purmodel1;
    DefaultTableModel purmodel2;
    DefaultTableModel stotodaymodel;
    DefaultTableModel stotodayviewmodel;
    DefaultTableModel stosearchmodel;
    DefaultTableModel stosearchviewmodel; 
        SimpleDateFormat dcn=new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss:a");
        java.util.Date date=new java.util.Date();
    public module3(String empname) {
        purdbconnection();
        initComponents();
        purempidt.setText(empname);
        Image icon=new ImageIcon(this.getClass().getResource("/desktop.png")).getImage();
        this.setIconImage(icon);
        purmodel1.addColumn("MEDICINE'SID");
        purmodel1.addColumn("MEDICINE'SNAME");
        purmodel1.addColumn("CATEGORY");
        purmodel1.addColumn("ONCERATE");
        purmodel1.addColumn("SLIPQUANTITY");
        purmodel1.addColumn("SLIPRATE");
        purmodel1.addColumn("ML");
        purmodel1.addColumn("MG");
        purmodel1.addColumn("NUMOFTABLETS");
        purmodel1.addColumn("EXPIREYDATE");
        purmodel1.addColumn("JOINDATE");
        purmodel1.addColumn("LASTUPDATE");
        pursearchtable.setOpaque(true);
        pursearchtable.setFillsViewportHeight(true);
        purmodel2.addColumn("MEDICINE NAME");
        purmodel2.addColumn("NUM OF MEDINCE");
        purmodel2.addColumn("RATE");
        puraddtable.setOpaque(true);
        puraddtable.setFillsViewportHeight(true);
        //stotodaymodel
        stotodaymodel.addColumn("CUST ID");
        stotodaymodel.addColumn("EMP ID");
        stotodaymodel.addColumn("MEDICINE'S DETAILS");
        stotodaymodel.addColumn("TOT AMOUNT");
        stotodaymodel.addColumn("CUST MAIL-ID");
        stotodaymodel.addColumn("PURCHASE TIME");
        stotodaymodel.addColumn("PURCHASE DATE");
        stotodaytable.setOpaque(true);
        stotodaytable.setFillsViewportHeight(true);
        //stotodayviewmodel
        stotodayviewmodel.addColumn("MEDICINE NAME");
        stotodayviewmodel.addColumn("NUM OF MEDINCE");
        stotodayviewmodel.addColumn("RATE");
        stotodayviewtable.setOpaque(true);
        stotodayviewtable.setFillsViewportHeight(true);
        //stosearchmodel
        stosearchmodel.addColumn("CUST ID");
        stosearchmodel.addColumn("EMP ID");
        stosearchmodel.addColumn("MEDICINE'S DETAILS");
        stosearchmodel.addColumn("TOT AMOUNT");
        stosearchmodel.addColumn("CUST MAIL-ID");
        stosearchmodel.addColumn("PURCHASE TIME");
        stosearchmodel.addColumn("PURCHASE DATE");
        stosearchtable.setOpaque(true);
        stosearchtable.setFillsViewportHeight(true);
        purdate();
        purtime();
        purdefault();

    }
       
    private void purdate(){
        Date d=new Date();
        purdatet.setText(sf.format(d));
    }
    private void purtime(){
        
         Timer t=new Timer(0,new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                Date timedate=new Date();
                String tt=sdf.format(timedate);
                purtimet.setText(tt);
            }
        });
        t.start();
    }
    
    private void purdefault(){
        pursearcht.setText("");
        purmedcategoryt.setText("NULL");
        purmedcategory.setSelectedIndex(0);
        purtabnamet.setText("NULL");
        purtabaddc.setSelectedIndex(0);
        purtabaddt.setText("");
        purtabratet.setText("NULL");
        puradd.setEnabled(false);
        purclear.setEnabled(false);
        purprintcategory.setSelectedIndex(0);
        purconfirm.setEnabled(false);
        purconfirm.setVisible(true);
        purprint.setVisible(false);
        puraddtable.setEnabled(false);
        purconfirm();
        purtotamount();
        try{
            ResultSet sr=stmt.executeQuery("select custid from salseitem");
            int big=0;
            while(sr.next()){
                if(big<Integer.valueOf(sr.getString(1).substring(4)))
                    big=Integer.valueOf(sr.getString(1).substring(4));
            }
            int i;
            for(i=1;i<=big++;i++){
                int count=0;
                ResultSet s=stmt.executeQuery("select custid from salseitem");
                while(s.next()){
                    if(i==Integer.valueOf(s.getString(1).substring(4))){
                        count++;
                        break;
                }
            }
            if(count==1)
                continue;
            else 
                break;
            }
            purcustidt.setText("cust"+i);
        }
        catch(Exception z){
            System.out.println(z);
        }
    }
    private void purconfirm(){
        if(0<purmodel2.getRowCount()){
            purconfirm.setEnabled(true);
            puraddtable.setEnabled(true);
            purprint.setVisible(false);
        }
    }
    private void purtotamount(){
        purtot=0;
        for(int c=0;c<purmodel2.getRowCount();c++)
            purtot+=Integer.valueOf(purmodel2.getValueAt(c,2).toString());
       purtott.setText(String.valueOf(purtot+"  "+"Rs"));
    }
    private void purdbconnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical","root","");
            stmt=con.createStatement();
        }
        catch(ClassNotFoundException | SQLException z){
           JOptionPane.showMessageDialog(this,"Check Datebase Connection..");
           System.exit(0);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        purempidl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        purdatel = new javax.swing.JLabel();
        purtimel = new javax.swing.JLabel();
        purdatet = new javax.swing.JLabel();
        purtimet = new javax.swing.JLabel();
        purempidt = new javax.swing.JLabel();
        purcategory = new javax.swing.JTabbedPane();
        purmailpanel = new javax.swing.JPanel();
        pursearchl = new javax.swing.JLabel();
        purclear = new javax.swing.JButton();
        pursearcht = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        pursearchtable = new javax.swing.JTable();
        purmedcategory = new javax.swing.JTabbedPane();
        purtabpanel = new javax.swing.JPanel();
        purtabnamel = new javax.swing.JLabel();
        purtabnamet = new javax.swing.JLabel();
        purtabaddc = new javax.swing.JComboBox<>();
        purtabaddt = new javax.swing.JTextField();
        purtabratel = new javax.swing.JLabel();
        purtabratet = new javax.swing.JLabel();
        purliqpanel = new javax.swing.JPanel();
        purliqnamel = new javax.swing.JLabel();
        purliqnamet = new javax.swing.JLabel();
        purliqaddl = new javax.swing.JLabel();
        purliqaddt = new javax.swing.JTextField();
        purliqratel = new javax.swing.JLabel();
        purliqratet = new javax.swing.JLabel();
        purinhpanel = new javax.swing.JPanel();
        purinhnamel = new javax.swing.JLabel();
        purinhnamet = new javax.swing.JLabel();
        purinhaddl = new javax.swing.JLabel();
        purinhaddt = new javax.swing.JTextField();
        purinhratel = new javax.swing.JLabel();
        purinhratet = new javax.swing.JLabel();
        puritmpanel = new javax.swing.JPanel();
        puritmnamel = new javax.swing.JLabel();
        puritmaddl = new javax.swing.JLabel();
        puritmaddt = new javax.swing.JTextField();
        puritmratel = new javax.swing.JLabel();
        puritmnamet = new javax.swing.JLabel();
        puritmratet = new javax.swing.JLabel();
        hide = new javax.swing.JLabel();
        puradd = new javax.swing.JButton();
        purmedcategoryl = new javax.swing.JLabel();
        pursalse = new javax.swing.JButton();
        purcustidl = new javax.swing.JLabel();
        purmedcategoryt = new javax.swing.JLabel();
        purprintcategory = new javax.swing.JTabbedPane();
        puraddtablepanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        puraddtable = new javax.swing.JTable();
        purbillpanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        purbill = new javax.swing.JTextArea();
        purmaill = new javax.swing.JLabel();
        purmailt = new javax.swing.JTextField();
        purconfirm = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        purcustidt = new javax.swing.JLabel();
        purprint = new javax.swing.JButton();
        purtotl = new javax.swing.JLabel();
        purtott = new javax.swing.JLabel();
        pursalsedetails = new javax.swing.JPanel();
        purbpanel = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        pursalsecategory = new javax.swing.JTabbedPane();
        stotodaypanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        stotodaytable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        stotodayviewtable = new javax.swing.JTable();
        stocustidt = new javax.swing.JLabel();
        stoempidt = new javax.swing.JLabel();
        stosalsedatet = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        stocustmailidt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        stotodaytott = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        stosearchpanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        stosearchtable = new javax.swing.JTable();
        stosearchtot = new com.toedter.calendar.JDateChooser();
        stosearchfromt = new com.toedter.calendar.JDateChooser();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        stosearch = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        stosearchtott = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        stosearchviewtable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(" PURCHASE SIDE OF JMC MEDICAL");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));

        jButton1.setBackground(new java.awt.Color(128, 123, 123));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        purempidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purempidl.setText("EMPLOYEE ID");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("JMC MEDICAL PURCHASE PAGE");

        purdatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purdatel.setText("DATE");

        purtimel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purtimel.setText("TIME");

        purdatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purdatet.setForeground(new java.awt.Color(255, 255, 255));
        purdatet.setText("date");

        purtimet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purtimet.setForeground(new java.awt.Color(255, 255, 255));
        purtimet.setText("time");

        purempidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purempidt.setForeground(new java.awt.Color(255, 255, 255));
        purempidt.setText("empid");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(purdatel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(purtimel))
                    .addComponent(purempidl, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(purempidt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(purdatet, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(purtimet, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(purdatel)
                .addGap(12, 12, 12)
                .addComponent(purtimel)
                .addGap(6, 6, 6)
                .addComponent(purempidl))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(purdatet)
                .addGap(8, 8, 8)
                .addComponent(purtimet)
                .addGap(2, 2, 2)
                .addComponent(purempidt))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        purmailpanel.setBackground(new java.awt.Color(120, 185, 170));
        purmailpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pursearchl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pursearchl.setForeground(new java.awt.Color(255, 255, 255));
        pursearchl.setText("ENTER THE MEDICNE NAME TO SEARCH  :");
        purmailpanel.add(pursearchl, new org.netbeans.lib.awtextra.AbsoluteConstraints(194, 54, 250, 20));

        purclear.setBackground(new java.awt.Color(128, 123, 123));
        purclear.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        purclear.setForeground(new java.awt.Color(255, 255, 255));
        purclear.setText("CLEAR");
        purclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purclearActionPerformed(evt);
            }
        });
        purmailpanel.add(purclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 300, 100, 150));

        pursearcht.setBackground(new java.awt.Color(120, 185, 170));
        pursearcht.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pursearcht.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        pursearcht.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pursearchtActionPerformed(evt);
            }
        });
        pursearcht.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pursearchtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pursearchtKeyTyped(evt);
            }
        });
        purmailpanel.add(pursearcht, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 51, 111, 20));

        purmodel1=new DefaultTableModel();
        pursearchtable.setBackground(new java.awt.Color(255, 102, 102));
        pursearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pursearchtable.setForeground(new java.awt.Color(255, 255, 255));
        pursearchtable.setModel(purmodel1);
        pursearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pursearchtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(pursearchtable);

        purmailpanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 91, 802, 92));

        purmedcategory.setTabPlacement(javax.swing.JTabbedPane.RIGHT);

        purtabpanel.setBackground(new java.awt.Color(120, 185, 170));
        purtabpanel.setLayout(null);

        purtabnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purtabnamel.setText("TABLET NAME");
        purtabpanel.add(purtabnamel);
        purtabnamel.setBounds(0, 0, 130, 25);

        purtabnamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purtabnamet.setText("NULL");
        purtabpanel.add(purtabnamet);
        purtabnamet.setBounds(155, 0, 110, 25);

        purtabaddc.setBackground(new java.awt.Color(255, 102, 102));
        purtabaddc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TABLETS", "SLIP"}));
        purtabaddc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                purtabaddcItemStateChanged(evt);
            }
        });
        purtabaddc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purtabaddcActionPerformed(evt);
            }
        });
        purtabpanel.add(purtabaddc);
        purtabaddc.setBounds(0, 50, 100, 25);

        purtabaddt.setBackground(new java.awt.Color(120, 185, 170));
        purtabaddt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purtabaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        purtabaddt.setMaximumSize(new java.awt.Dimension(75, 25));
        purtabaddt.setMinimumSize(new java.awt.Dimension(75, 25));
        purtabaddt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purtabaddtActionPerformed(evt);
            }
        });
        purtabaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                purtabaddtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                purtabaddtKeyTyped(evt);
            }
        });
        purtabpanel.add(purtabaddt);
        purtabaddt.setBounds(155, 50, 75, 25);

        purtabratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purtabratel.setText("RATE OF TABLET");
        purtabpanel.add(purtabratel);
        purtabratel.setBounds(0, 100, 130, 25);

        purtabratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purtabratet.setText("NULL");
        purtabpanel.add(purtabratet);
        purtabratet.setBounds(155, 100, 100, 25);

        purmedcategory.addTab("tab1", purtabpanel);

        purliqpanel.setBackground(new java.awt.Color(120, 185, 170));
        purliqpanel.setLayout(null);

        purliqnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purliqnamel.setText("LIQUID NAME");
        purliqpanel.add(purliqnamel);
        purliqnamel.setBounds(0, 0, 130, 25);

        purliqnamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purliqnamet.setText("NULL");
        purliqpanel.add(purliqnamet);
        purliqnamet.setBounds(155, 0, 100, 25);

        purliqaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purliqaddl.setText("NUM OF LIQUIDS");
        purliqpanel.add(purliqaddl);
        purliqaddl.setBounds(0, 50, 130, 25);

        purliqaddt.setBackground(new java.awt.Color(120, 185, 170));
        purliqaddt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purliqaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        purliqaddt.setMaximumSize(new java.awt.Dimension(75, 25));
        purliqaddt.setMinimumSize(new java.awt.Dimension(75, 25));
        purliqaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                purliqaddtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                purliqaddtKeyTyped(evt);
            }
        });
        purliqpanel.add(purliqaddt);
        purliqaddt.setBounds(155, 50, 75, 25);

        purliqratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purliqratel.setText("RATE OF LIQUIDS");
        purliqpanel.add(purliqratel);
        purliqratel.setBounds(0, 100, 130, 25);

        purliqratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purliqratet.setText("NULL");
        purliqpanel.add(purliqratet);
        purliqratet.setBounds(155, 100, 100, 25);

        purmedcategory.addTab("tab2", purliqpanel);

        purinhpanel.setBackground(new java.awt.Color(120, 185, 170));
        purinhpanel.setLayout(null);

        purinhnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purinhnamel.setText("INHALER NAME");
        purinhpanel.add(purinhnamel);
        purinhnamel.setBounds(0, 0, 130, 25);

        purinhnamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purinhnamet.setText("NULL");
        purinhpanel.add(purinhnamet);
        purinhnamet.setBounds(155, 0, 100, 25);

        purinhaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purinhaddl.setText("NUM OF INHALER");
        purinhpanel.add(purinhaddl);
        purinhaddl.setBounds(0, 50, 130, 25);

        purinhaddt.setBackground(new java.awt.Color(120, 185, 170));
        purinhaddt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purinhaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        purinhaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                purinhaddtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                purinhaddtKeyTyped(evt);
            }
        });
        purinhpanel.add(purinhaddt);
        purinhaddt.setBounds(155, 50, 75, 25);

        purinhratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purinhratel.setText("RATE OF INHALER");
        purinhpanel.add(purinhratel);
        purinhratel.setBounds(0, 100, 130, 25);

        purinhratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purinhratet.setText("NULL");
        purinhpanel.add(purinhratet);
        purinhratet.setBounds(155, 100, 100, 25);

        purmedcategory.addTab("tab3", purinhpanel);

        puritmpanel.setBackground(new java.awt.Color(120, 185, 170));
        puritmpanel.setLayout(null);

        puritmnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        puritmnamel.setText("ITEM NAME");
        puritmpanel.add(puritmnamel);
        puritmnamel.setBounds(0, 0, 130, 25);

        puritmaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        puritmaddl.setText("NUM OF ITEM");
        puritmpanel.add(puritmaddl);
        puritmaddl.setBounds(0, 50, 130, 25);

        puritmaddt.setBackground(new java.awt.Color(120, 185, 170));
        puritmaddt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        puritmaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        puritmaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                puritmaddtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                puritmaddtKeyTyped(evt);
            }
        });
        puritmpanel.add(puritmaddt);
        puritmaddt.setBounds(155, 50, 75, 25);

        puritmratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        puritmratel.setText("RATE OF ITEM");
        puritmpanel.add(puritmratel);
        puritmratel.setBounds(0, 100, 130, 25);

        puritmnamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        puritmnamet.setText("NULL                 ");
        puritmpanel.add(puritmnamet);
        puritmnamet.setBounds(155, 0, 100, 25);

        puritmratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        puritmratet.setText("NULL");
        puritmpanel.add(puritmratet);
        puritmratet.setBounds(155, 100, 100, 25);

        purmedcategory.addTab("tab4", puritmpanel);

        purmailpanel.add(purmedcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(62, 314, 320, 130));

        hide.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        hide.setForeground(new java.awt.Color(255, 255, 255));
        hide.setText("PURCHASE DETAILS");
        purmailpanel.add(hide, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, -1, 30));

        puradd.setBackground(new java.awt.Color(128, 123, 123));
        puradd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        puradd.setForeground(new java.awt.Color(255, 255, 255));
        puradd.setText("ADD TO PURCHASE");
        puradd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                puraddActionPerformed(evt);
            }
        });
        purmailpanel.add(puradd, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 470, 150, 34));

        purmedcategoryl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purmedcategoryl.setText("MEDICINE CATEGORY");
        purmailpanel.add(purmedcategoryl, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 130, 24));

        pursalse.setBackground(new java.awt.Color(128, 123, 123));
        pursalse.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pursalse.setForeground(new java.awt.Color(255, 255, 255));
        pursalse.setText("SALSE DETAILS");
        pursalse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pursalseActionPerformed(evt);
            }
        });
        purmailpanel.add(pursalse, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 40, 120, 32));

        purcustidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purcustidl.setText("CUST-ID");
        purmailpanel.add(purcustidl, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 55, 20));

        purmedcategoryt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purmedcategoryt.setText("NULL");
        purmailpanel.add(purmedcategoryt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 80, 20));

        purprintcategory.setTabPlacement(javax.swing.JTabbedPane.RIGHT);

        puraddtablepanel.setBackground(new java.awt.Color(120, 185, 170));

        purmodel2=new DefaultTableModel();
        puraddtable.setBackground(new java.awt.Color(255, 102, 102));
        puraddtable.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        puraddtable.setForeground(new java.awt.Color(255, 255, 255));
        puraddtable.setModel(purmodel2);
        puraddtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                puraddtableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(puraddtable);

        javax.swing.GroupLayout puraddtablepanelLayout = new javax.swing.GroupLayout(puraddtablepanel);
        puraddtablepanel.setLayout(puraddtablepanelLayout);
        puraddtablepanelLayout.setHorizontalGroup(
            puraddtablepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(puraddtablepanelLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        puraddtablepanelLayout.setVerticalGroup(
            puraddtablepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(puraddtablepanelLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                .addContainerGap())
        );

        purprintcategory.addTab("tab2", puraddtablepanel);

        purbillpanel.setBackground(new java.awt.Color(120, 185, 170));

        purbill.setColumns(20);
        purbill.setRows(6);
        jScrollPane3.setViewportView(purbill);

        purmaill.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purmaill.setText("CUSTOMER'S MAIL ID");

        purmailt.setBackground(new java.awt.Color(120, 185, 170));
        purmailt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purmailt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        purmailt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purmailtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout purbillpanelLayout = new javax.swing.GroupLayout(purbillpanel);
        purbillpanel.setLayout(purbillpanelLayout);
        purbillpanelLayout.setHorizontalGroup(
            purbillpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, purbillpanelLayout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
            .addGroup(purbillpanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(purmaill)
                .addGap(43, 43, 43)
                .addComponent(purmailt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        purbillpanelLayout.setVerticalGroup(
            purbillpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(purbillpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(purbillpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(purmaill, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(purmailt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        purprintcategory.addTab("tab1", purbillpanel);

        purmailpanel.add(purprintcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 230, 470, 220));

        purconfirm.setBackground(new java.awt.Color(128, 123, 123));
        purconfirm.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purconfirm.setForeground(new java.awt.Color(255, 255, 255));
        purconfirm.setText("CONFIRM TO BUY");
        purconfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purconfirmActionPerformed(evt);
            }
        });
        purmailpanel.add(purconfirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, 130, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PURCHASE TABLE");
        purmailpanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, 120, -1));

        purcustidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        purcustidt.setText("NULL");
        purmailpanel.add(purcustidt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, 70, -1));

        purprint.setBackground(new java.awt.Color(128, 123, 123));
        purprint.setForeground(new java.awt.Color(255, 255, 255));
        purprint.setText("PRINT THE BILL");
        purprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purprintActionPerformed(evt);
            }
        });
        purmailpanel.add(purprint, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, 130, 30));

        purtotl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purtotl.setForeground(new java.awt.Color(255, 255, 255));
        purtotl.setText("TOTAL AMOUNT");
        purmailpanel.add(purtotl, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 470, -1, 30));

        purtott.setForeground(new java.awt.Color(255, 255, 255));
        purtott.setText("0 Rs");
        purmailpanel.add(purtott, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 476, 60, 20));

        purcategory.addTab("tab1", purmailpanel);

        purbpanel.setBackground(new java.awt.Color(120, 185, 170));
        purbpanel.setLayout(null);

        jButton3.setBackground(new java.awt.Color(128, 123, 123));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("TODAY'S SALSE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        purbpanel.add(jButton3);
        jButton3.setBounds(20, 240, 162, 73);

        jButton2.setBackground(new java.awt.Color(128, 123, 123));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("SEARCH SALSE DETAILS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        purbpanel.add(jButton2);
        jButton2.setBounds(20, 390, 162, 74);

        jButton6.setBackground(new java.awt.Color(128, 123, 123));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("BACK TO PURCHASE PAGE");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        purbpanel.add(jButton6);
        jButton6.setBounds(30, 80, 150, 70);

        pursalsecategory.setTabPlacement(javax.swing.JTabbedPane.RIGHT);

        stotodaypanel.setBackground(new java.awt.Color(120, 185, 170));
        stotodaypanel.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TODAY'S SALSE DETAILS");
        stotodaypanel.add(jLabel5);
        jLabel5.setBounds(200, 20, 211, 25);

        stotodaymodel=new DefaultTableModel();
        stotodaytable.setBackground(new java.awt.Color(255, 102, 102));
        stotodaytable.setForeground(new java.awt.Color(255, 255, 255));
        stotodaytable.setModel(stotodaymodel);
        stotodaytable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stotodaytableMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(stotodaytable);

        stotodaypanel.add(jScrollPane7);
        jScrollPane7.setBounds(20, 60, 610, 240);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CUSTOMER DETAILS");
        stotodaypanel.add(jLabel4);
        jLabel4.setBounds(120, 320, 114, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("CUSTOMER ID");
        stotodaypanel.add(jLabel6);
        jLabel6.setBounds(40, 370, 110, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("EMPLOYEE ID");
        stotodaypanel.add(jLabel7);
        jLabel7.setBounds(40, 400, 110, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("SALSE DATE");
        stotodaypanel.add(jLabel8);
        jLabel8.setBounds(40, 430, 100, 20);

        stotodayviewmodel=new DefaultTableModel();
        stotodayviewtable.setBackground(new java.awt.Color(255, 102, 102));
        stotodayviewtable.setModel(stotodayviewmodel);
        jScrollPane8.setViewportView(stotodayviewtable);

        stotodaypanel.add(jScrollPane8);
        jScrollPane8.setBounds(270, 320, 270, 130);

        stocustidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stocustidt.setText("NULL");
        stotodaypanel.add(stocustidt);
        stocustidt.setBounds(180, 370, 80, 20);

        stoempidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stoempidt.setText("NULL");
        stotodaypanel.add(stoempidt);
        stoempidt.setBounds(180, 400, 90, 20);

        stosalsedatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stosalsedatet.setText("NULL");
        stotodaypanel.add(stosalsedatet);
        stosalsedatet.setBounds(180, 430, 90, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("CUSTOMER MAIL ID");
        stotodaypanel.add(jLabel12);
        jLabel12.setBounds(40, 460, 120, 20);

        stocustmailidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stocustmailidt.setText("NULL");
        stotodaypanel.add(stocustmailidt);
        stocustmailidt.setBounds(180, 460, 130, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("TOTAL AMOUNT");
        stotodaypanel.add(jLabel9);
        jLabel9.setBounds(460, 470, 100, 16);

        stotodaytott.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stotodaytott.setText("0 Rs");
        stotodaypanel.add(stotodaytott);
        stotodaytott.setBounds(590, 470, 70, 20);

        jButton7.setBackground(new java.awt.Color(128, 123, 123));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("TAKE DOC");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        stotodaypanel.add(jButton7);
        jButton7.setBounds(560, 330, 90, 30);

        pursalsecategory.addTab("tab1", stotodaypanel);

        stosearchpanel.setBackground(new java.awt.Color(120, 185, 170));
        stosearchpanel.setLayout(null);

        stosearchmodel=new DefaultTableModel();
        stosearchtable.setBackground(new java.awt.Color(255, 102, 102));
        stosearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stosearchtable.setForeground(new java.awt.Color(255, 255, 255));
        stosearchtable.setModel(stosearchmodel);
        stosearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stosearchtableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(stosearchtable);

        stosearchpanel.add(jScrollPane4);
        jScrollPane4.setBounds(30, 100, 580, 220);

        stosearchtot.setBackground(new java.awt.Color(120, 185, 170));
        stosearchtot.setDateFormatString("yyyy-MM-dd");
        stosearchpanel.add(stosearchtot);
        stosearchtot.setBounds(410, 50, 116, 22);

        stosearchfromt.setBackground(new java.awt.Color(120, 185, 170));
        stosearchfromt.setDateFormatString("yyyy-MM-dd");
        stosearchpanel.add(stosearchfromt);
        stosearchfromt.setBounds(250, 50, 116, 22);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("FROM");
        stosearchpanel.add(jLabel11);
        jLabel11.setBounds(200, 52, 40, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("TO");
        stosearchpanel.add(jLabel13);
        jLabel13.setBounds(380, 50, 30, 22);

        stosearch.setBackground(new java.awt.Color(128, 123, 123));
        stosearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stosearch.setForeground(new java.awt.Color(255, 255, 255));
        stosearch.setText("SEARCH");
        stosearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stosearchActionPerformed(evt);
            }
        });
        stosearchpanel.add(stosearch);
        stosearch.setBounds(560, 50, 90, 30);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("ENTER THE DATE TO SEARCH");
        stosearchpanel.add(jLabel14);
        jLabel14.setBounds(28, 53, 170, 22);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("TOTAL AMOUNT ");
        stosearchpanel.add(jLabel10);
        jLabel10.setBounds(490, 380, 96, 22);

        stosearchtott.setText("0 Rs");
        stosearchpanel.add(stosearchtott);
        stosearchtott.setBounds(590, 380, 70, 22);

        jButton8.setBackground(new java.awt.Color(128, 123, 123));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("TAKE DOC");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        stosearchpanel.add(jButton8);
        jButton8.setBounds(30, 360, 110, 30);

        stosearchviewmodel=new DefaultTableModel();
        stosearchviewtable.setBackground(new java.awt.Color(255, 102, 102));
        stosearchviewtable.setModel(stosearchviewmodel);
        jScrollPane9.setViewportView(stosearchviewtable);

        stosearchpanel.add(jScrollPane9);
        jScrollPane9.setBounds(150, 350, 320, 130);

        pursalsecategory.addTab("tab2", stosearchpanel);

        javax.swing.GroupLayout pursalsedetailsLayout = new javax.swing.GroupLayout(pursalsedetails);
        pursalsedetails.setLayout(pursalsedetailsLayout);
        pursalsedetailsLayout.setHorizontalGroup(
            pursalsedetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(purbpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(pursalsedetailsLayout.createSequentialGroup()
                .addGap(201, 201, 201)
                .addComponent(pursalsecategory, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pursalsedetailsLayout.setVerticalGroup(
            pursalsedetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pursalsedetailsLayout.createSequentialGroup()
                .addGroup(pursalsedetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(purbpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pursalsedetailsLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(pursalsecategory, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        purcategory.addTab("tab2", pursalsedetails);

        getContentPane().add(purcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 870, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new module1().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void pursearchtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pursearchtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pursearchtActionPerformed

    private void purclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purclearActionPerformed
        purdefault();
    }//GEN-LAST:event_purclearActionPerformed

    private void pursearchtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pursearchtKeyReleased
        if(pursearcht.getText().equals("")||pursearcht.getText().contains(" "));
           else{
                try{
                    ResultSet rx=stmt.executeQuery("select * from medicine where medname like '"+pursearcht.getText()+"%' ");
                    while(rx.next())
                            purmodel1.addRow(new Object[]{rx.getString(1),rx.getString(2),rx.getString(3),rx.getInt(4),rx.getInt(5),rx.getInt(6),rx.getInt(7),rx.getInt(8),rx.getInt(9),rx.getString(10),rx.getString(11),rx.getString(12)});
                }
                catch(SQLException j){
                    System.out.println(j);
                }
            }
    }//GEN-LAST:event_pursearchtKeyReleased

    private void pursearchtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pursearchtKeyTyped
        purmodel1.setRowCount(0);
    }//GEN-LAST:event_pursearchtKeyTyped

    private void purtabaddtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purtabaddtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purtabaddtActionPerformed

    private void puraddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_puraddActionPerformed
        if(purmedcategoryt.getText().equals("TABLETS")){
            if(purtabaddc.getSelectedItem()=="SLIP")
                    purmodel2.addRow(new Object[]{purtabnamet.getText(),"Slip "+purtabaddt.getText(),purtabratet.getText()});
                else
                    purmodel2.addRow(new Object[]{purtabnamet.getText(),"Tablets "+purtabaddt.getText(),purtabratet.getText()});
        }
        else if(purmedcategoryt.getText().equals("LIQUID")){
            purmodel2.addRow(new Object[]{purliqnamet.getText(),"Liquid "+purliqaddt.getText(),purliqratet.getText()});
        }
        else if(purmedcategoryt.getText().equals("INHALERS")){
            purmodel2.addRow(new Object[]{purinhnamet.getText(),"Inhalers "+purinhaddt.getText(),purinhratet.getText()});
        }
        else{
            purmodel2.addRow(new Object[]{puritmnamet.getText(),"Item "+puritmaddt.getText(),puritmratet.getText()});
        }
        purdefault();
    }//GEN-LAST:event_puraddActionPerformed

    private void purtabaddcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purtabaddcActionPerformed
            
                                                   
    }//GEN-LAST:event_purtabaddcActionPerformed

    private void pursearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pursearchtableMouseClicked
        try{
           int selected=pursearchtable.getSelectedRow();
           Date expdate=sf.parse(purmodel1.getValueAt(selected, 9).toString());
           Date todaydate=sf.parse(purdatet.getText());
            if(expdate.compareTo(todaydate)>=0){
                       if(purmodel1.getValueAt(selected,2).toString().equals("TABLETS")){
                            purmedcategory.setSelectedIndex(0);
                            purmedcategoryt.setText(purmodel1.getValueAt(selected,2).toString());
                            purtabnamet.setText(purmodel1.getValueAt(selected,1).toString());
                            purtabaddt.setText("1");
                            purtabaddc.setSelectedIndex(0);
                            purtabratet.setText(purmodel1.getValueAt(selected,3).toString());
                            purmodel1.setRowCount(0);
                            pursearcht.setText("");              
                        }
                        else if(purmodel1.getValueAt(selected,2).toString().equals("LIQUID")){
                            purmedcategory.setSelectedIndex(1);
                            purmedcategoryt.setText(purmodel1.getValueAt(selected,2).toString());
                            purliqnamet.setText(purmodel1.getValueAt(selected,1).toString());
                            purliqaddt.setText("1");
                            purliqratet.setText(purmodel1.getValueAt(selected,3).toString());
                            purmodel1.setRowCount(0);
                            pursearcht.setText("");
                        }
                        else if(purmodel1.getValueAt(selected,2).toString().equals("INHALERS")){
                            purmedcategory.setSelectedIndex(2);
                            purmedcategoryt.setText(purmodel1.getValueAt(selected,2).toString());
                            purinhnamet.setText(purmodel1.getValueAt(selected,1).toString());
                            purinhaddt.setText("1");
                            purinhratet.setText(purmodel1.getValueAt(selected,3).toString());
                            purmodel1.setRowCount(0);
                            pursearcht.setText("");
                        }
                        else if(purmodel1.getValueAt(selected,2).toString().equals("OTHERS")){
                            purmedcategory.setSelectedIndex(3);
                            purmedcategoryt.setText(purmodel1.getValueAt(selected,2).toString());
                            puritmnamet.setText(purmodel1.getValueAt(selected,1).toString());
                            puritmaddt.setText("1");
                            puritmratet.setText(purmodel1.getValueAt(selected,3).toString());
                            purmodel1.setRowCount(0);
                            pursearcht.setText("");
                        }
                            puradd.setEnabled(true);
                            purclear.setEnabled(true);
            }
            else{
                JOptionPane.showMessageDialog(this,"Medicine has expiryed.");
            }

        }   
        catch(Exception j){
                System.out.println(j);
        } 
    }//GEN-LAST:event_pursearchtableMouseClicked

    private void pursalseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pursalseActionPerformed
            purcategory.setSelectedIndex(1);
            try{
            //stocategory.setSelectedIndex(0);
            stotodaymodel.setRowCount(0);
            ResultSet ry=stmt.executeQuery("select * from salseitem where purchasedate='"+java.time.LocalDate.now().toString()+"'");
            while(ry.next())
                stotodaymodel.addRow(new Object[]{ry.getString(1),ry.getString(2),ry.getString(3),ry.getString(4),ry.getString(5),ry.getString(6),ry.getString(7)});           
            if(stotodaymodel.getRowCount()<=0);
            else{
            stocustidt.setText(stotodaymodel.getValueAt(0,0).toString());
            stoempidt.setText(stotodaymodel.getValueAt(0,1).toString());
            stocustmailidt.setText(stotodaymodel.getValueAt(0,4).toString());
            stosalsedatet.setText(stotodaymodel.getValueAt(0,6).toString());
            String sto=stotodaymodel.getValueAt(0,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            stotodayviewmodel.setRowCount(0);
            for(int i=0;i<stoarray.length;i++){
                stotodayviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                
                i+=2;
            }
            stotodaytott.setText(stotodaymodel.getValueAt(0,3).toString());
        }
        }
        catch(Exception z){
            System.out.println(z);
        }
    }//GEN-LAST:event_pursalseActionPerformed

    private void purtabaddcItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_purtabaddcItemStateChanged
         if(purtabaddt.getText().equals("")||purtabaddt.getText().contains(" "))
            purtabratet.setText("");
         else{
                if(purtabaddc.getSelectedItem()=="SLIP"){
                    try {
                        ResultSet rx= stmt.executeQuery("select sliprate from  medicine where medname='"+purtabnamet.getText()+"' ");
                         while(rx.next())
                            purtabratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purtabaddt.getText())));
                        
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(module3.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
                    //tabactualtabletst.setText(String.valueOf(Integer.valueOf(tabaddtabletst.getText())*Integer.valueOf(tabslipquantityt.getText())));
                else if(purtabaddc.getSelectedItem()=="TABLETS"){
                    try {
                        ResultSet rx= stmt.executeQuery("select oncerate from  medicine where medname='"+purtabnamet.getText()+"' ");
                         while(rx.next())
                            purtabratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purtabaddt.getText())));
                        
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(module3.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
            }                                          
    }//GEN-LAST:event_purtabaddcItemStateChanged

    private void purtabaddtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purtabaddtKeyReleased
        if(purtabaddt.getText().equals("")||purtabaddt.getText().contains(" "))
            purtabratet.setText("");
         else{
                if(purtabaddc.getSelectedItem()=="SLIP"){
                    try {
                        ResultSet rx= stmt.executeQuery("select sliprate from  medicine where medname='"+purtabnamet.getText()+"' ");
                         while(rx.next())
                            purtabratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purtabaddt.getText())));
                        
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(module3.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
                    //tabactualtabletst.setText(String.valueOf(Integer.valueOf(tabaddtabletst.getText())*Integer.valueOf(tabslipquantityt.getText())));
                else if(purtabaddc.getSelectedItem()=="TABLETS"){
                    try {
                        ResultSet rx= stmt.executeQuery("select oncerate from  medicine where medname='"+purtabnamet.getText()+"' ");
                         while(rx.next())
                            purtabratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purtabaddt.getText())));
                        
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(module3.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
            }
    }//GEN-LAST:event_purtabaddtKeyReleased

    private void purliqaddtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purliqaddtKeyReleased
        if(purliqaddt.getText().equals("")||purliqaddt.getText().contains(" "))
            purliqratet.setText("");
        else{
            try{
                ResultSet rx= stmt.executeQuery("select oncerate from  medicine where medname='"+purliqnamet.getText()+"' ");
                while(rx.next())
                    purliqratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purliqaddt.getText())));
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
    }//GEN-LAST:event_purliqaddtKeyReleased

    private void purinhaddtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purinhaddtKeyReleased
        if(purinhaddt.getText().equals("")||purinhaddt.getText().contains(" "))
            purinhratet.setText("");
        else{
            try{
                ResultSet rx= stmt.executeQuery("select oncerate from  medicine where medname='"+purinhnamet.getText()+"' ");
                while(rx.next())
                    purinhratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(purinhaddt.getText())));
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
    }//GEN-LAST:event_purinhaddtKeyReleased

    private void puritmaddtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_puritmaddtKeyReleased
        if(puritmaddt.getText().equals("")||puritmaddt.getText().contains(" "))
            puritmratet.setText("");
        else{
            try{
                ResultSet rx= stmt.executeQuery("select oncerate from  medicine where medname='"+puritmnamet.getText()+"' ");
                while(rx.next())
                    puritmratet.setText(String.valueOf(rx.getInt(1) * Integer.valueOf(puritmaddt.getText())));
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
    }//GEN-LAST:event_puritmaddtKeyReleased

    private void puraddtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_puraddtableMouseClicked
        int selected;
        selected=puraddtable.getSelectedRow();
        String demo=purmodel2.getValueAt(selected,1).toString();
        if(demo.substring(0,3).equals("Tab")||demo.substring(0,3).equals("Sli")){          
            if(demo.substring(0,3).equals("Tab")){
                purmedcategoryt.setText("TABLETS");
                purtabaddc.setSelectedIndex(0);
            }
            else{
                purmedcategoryt.setText("SLIP");
                purtabaddc.setSelectedIndex(1);
            }
            purmedcategory.setSelectedIndex(0);
            purtabnamet.setText(purmodel2.getValueAt(selected,0).toString());
            String retab[]=purmodel2.getValueAt(selected,1).toString().split(" ");
            purtabaddt.setText(retab[1]);
            purtabratet.setText(purmodel2.getValueAt(selected,2).toString());
            purmodel2.removeRow(puraddtable.getSelectedRow()); 
            puradd.setEnabled(true);
            purclear.setEnabled(true);
        }
        else if(demo.substring(0,3).equals("Liq")){          
            purmedcategoryt.setText("LIQUID");
             purmedcategory.setSelectedIndex(1);
             purliqnamet.setText(purmodel2.getValueAt(selected,0).toString());
             String reliq[]=purmodel2.getValueAt(selected,1).toString().split(" ");
            purliqaddt.setText(reliq[1]);
            purliqratet.setText(purmodel2.getValueAt(selected,2).toString());
            purmodel2.removeRow(puraddtable.getSelectedRow());   
            puradd.setEnabled(true);
            purclear.setEnabled(true);
        }
        else if(demo.substring(0,3).equals("Inh")){
            purmedcategoryt.setText("INHALERS");
             purmedcategory.setSelectedIndex(2);
             purinhnamet.setText(purmodel2.getValueAt(selected,0).toString());
             String reinh[]=purmodel2.getValueAt(selected,1).toString().split(" ");
            purinhaddt.setText(reinh[1]);
            purinhratet.setText(purmodel2.getValueAt(selected,2).toString());
            purmodel2.removeRow(puraddtable.getSelectedRow());   
            puradd.setEnabled(true);
            purclear.setEnabled(true);
        }
        else if(demo.substring(0,3).equals("Ite")){
            purmedcategoryt.setText("OTHERS");
            purmedcategory.setSelectedIndex(3);
            puritmnamet.setText(purmodel2.getValueAt(selected,0).toString());
            String reitm[]=purmodel2.getValueAt(selected,1).toString().split(" ");
            puritmaddt.setText(reitm[1]);
            puritmratet.setText(purmodel2.getValueAt(selected,2).toString());
            purmodel2.removeRow(puraddtable.getSelectedRow());   
            puradd.setEnabled(true);
            purclear.setEnabled(true);
        }
            
    }//GEN-LAST:event_puraddtableMouseClicked

    private void purconfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purconfirmActionPerformed
        purprintcategory.setSelectedIndex(1);
        purbill.selectAll();
        purbill.replaceSelection("");
        purconfirm.setVisible(false);
        purprint.setVisible(true);
        purbill.setFont(new Font("monospaced",Font.PLAIN,12));
         purbill.setText(purbill.getText()+"\n");
         purbill.setText(purbill.getText()+"                  JMC  Medical Shop                 \n");
         purbill.setText(purbill.getText()+"\n");
         purbill.setText(purbill.getText()+"EMPLOYEE ID   "+purempidt.getText()+"               Date "+purdatet.getText()+"\n");
         purbill.setText(purbill.getText()+"CUSTOMER ID   "+purcustidt.getText()+"               Time "+sdf.format(date)+"\n");
         purbill.setText(purbill.getText()+"\n");
         purbill.setText(purbill.getText()+"---------------------------------------------------"+"\n");
         purbill.setText(purbill.getText()+"    Medicine name       "+"Quality            "+"Rate"+"\n");
         purbill.setText(purbill.getText()+"---------------------------------------------------"+"\n");
         for(int c=0;c<purmodel2.getRowCount();c++){
               //1st column  for()
            int len1=purmodel2.getValueAt(c,0).toString().length();  
            for(int j=len1;j<20;j++){
                if(j==len1){
                    purbill.setText(purbill.getText()+"      "+purmodel2.getValueAt(c,0));
                }
                else{
                    purbill.setText(purbill.getText()+" ");
                }
            }
              //2nd column   for()
              len1=purmodel2.getValueAt(c,1).toString().length();
              for(int j=len1;j<16;j++){
                  if(j==len1){
                      purbill.setText(purbill.getText()+""+purmodel2.getValueAt(c,1));
                  }
                  else{
                    purbill.setText(purbill.getText()+" ");
                  }
              }
              //3rd column for()
              len1=purmodel2.getValueAt(c,2).toString().length();
              for(int j=len1;j<10;j++){
                  if(j==len1){
                      purbill.setText(purbill.getText()+"    "+purmodel2.getValueAt(c,2));
                  }
                  else{
                      purbill.setText(purbill.getText()+" ");
                  }
              }
              purbill.setText(purbill.getText()+"\n");
            }
            purbill.setText(purbill.getText()+"\n");
            purbill.setText(purbill.getText()+"\n");
            purbill.setText(purbill.getText()+"                       Total Amount = "+purtott.getText());
             purbill.setText(purbill.getText()+"\n");
              purbill.setText(purbill.getText()+"\n");
               purbill.setText(purbill.getText()+"Contact No : 9578342367\n");
    }//GEN-LAST:event_purconfirmActionPerformed

    private void purprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purprintActionPerformed
        try {
            String custarray[]=new String[purmodel2.getRowCount()*3];
            int z=0;
            for(int i=0;i<purmodel2.getRowCount();i++){
                for(int j=0;j<3;j++){
                    custarray[z]=purmodel2.getValueAt(i,j).toString();
                    if(j==1){
                        String remove[]=purmodel2.getValueAt(i, j).toString().split(" ");
                        if(remove[0].equals("Slip")){
                            ResultSet re= stmt.executeQuery("select slipquantity from medicine where medname='"+purmodel2.getValueAt(i,0).toString()+"'");
                            int y=0;
                            while(re.next()){
                                y=re.getInt(1);    
                            } 
                            stmt.executeUpdate("update medicine set numofmedicines=numofmedicines-"+Integer.valueOf(remove[1])*y+" where medname='"+purmodel2.getValueAt(i,0).toString()+"' ");                                              
                        }
                        else{
                            stmt.executeUpdate("update medicine set numofmedicines=numofmedicines-"+Integer.valueOf(remove[1])+" where medname='"+purmodel2.getValueAt(i,0).toString()+"'");
                        }
                    }
                    z++;
                }
            }
            if(purmailt.getText().isEmpty()){
                stmt.executeUpdate("insert into salseitem values ('"+purcustidt.getText()+"','"+purempidt.getText()+"','"+Arrays.toString(custarray)+"',"+purtot+",'"+null+"','"+purtimet.getText()+"','"+purdatet.getText()+"')");
                JOptionPane.showMessageDialog(this,"Details inserted into database, Click ok to get a bill.");
            }
            else{              
                if(purmailt.getText().contains("@")){
                    stmt.executeUpdate("insert into salseitem values ('"+purcustidt.getText()+"','"+purempidt.getText()+"','"+Arrays.toString(custarray)+"',"+purtot+",'"+purmailt.getText()+"','"+purtimet.getText()+"','"+purdatet.getText()+"')");
                    mail.purmail(custarray,purmailt.getText(),purcustidt.getText(),purtott.getText(),purempidt.getText());
                    JOptionPane.showMessageDialog(this,"Details inserted into database and sent to the recipient, Click ok to get a bill.");
                }
                else{
                   JOptionPane.showMessageDialog(this,"Invalid Mail account, Mail wont sent to this account.");
                   stmt.executeUpdate("insert into salseitem values ('"+purcustidt.getText()+"','"+purempidt.getText()+"','"+Arrays.toString(custarray)+"',"+purtot+",'"+null+"','"+purtimet.getText()+"','"+purdatet.getText()+"')");
                   JOptionPane.showMessageDialog(this,"Details inserted into database, Click ok to get a bill.");
                }
            }
          purbill.print();
          purmodel2.setRowCount(0);
          purdefault();  
            
        } 
            catch (Exception ex) {
            System.out.println(ex);
            }
        
    }//GEN-LAST:event_purprintActionPerformed

    private void purmailtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purmailtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purmailtActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        pursalsecategory.setSelectedIndex(0);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        pursalsecategory.setSelectedIndex(1);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        purcategory.setSelectedIndex(0);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void purtabaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purtabaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_purtabaddtKeyTyped

    private void purliqaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purliqaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_purliqaddtKeyTyped

    private void purinhaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purinhaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_purinhaddtKeyTyped

    private void puritmaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_puritmaddtKeyTyped
       char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_puritmaddtKeyTyped

    private void stotodaytableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stotodaytableMouseClicked
        if(stotodaymodel.getRowCount()<=0);
        else{
            stotodayviewmodel.setRowCount(0);
            int selected=stotodaytable.getSelectedRow();
            stocustidt.setText(stotodaymodel.getValueAt(selected,0).toString());
            stoempidt.setText(stotodaymodel.getValueAt(selected,1).toString());
            stocustmailidt.setText(stotodaymodel.getValueAt(selected,4).toString());
            stosalsedatet.setText(stotodaymodel.getValueAt(selected,6).toString());
            String sto=stotodaymodel.getValueAt(selected,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            for(int i=0;i<stoarray.length;i++){
                stotodayviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                i+=2;
            }
            stotodaytott.setText(stotodaymodel.getValueAt(selected,3).toString());
        }
    }//GEN-LAST:event_stotodaytableMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try{
            if(stotodaytable.getRowCount()<=0);
            else{
                stotodaytable.print();
            }
        }
        catch(Exception e){

        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void stosearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stosearchtableMouseClicked
        if(stosearchmodel.getRowCount()<=0);
        else{
            stosearchviewmodel.setRowCount(0);
            int selected=stosearchtable.getSelectedRow();
            String sto=stosearchmodel.getValueAt(selected,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            for(int i=0;i<stoarray.length;i++){
                stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                i+=2;
            }
        }
    }//GEN-LAST:event_stosearchtableMouseClicked

    private void stosearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stosearchActionPerformed
        stosearchmodel.setRowCount(0);
        if(stosearchfromt.getDate()==null&&stosearchtot.getDate()==null){
            JOptionPane.showMessageDialog(this,"Atleast fill one date field. Do you wamt one day's record ? Fill from date field.");
        }
        else if(stosearchfromt.getDate()!=null&&stosearchtot.getDate()==null){

            try{
                java.util.Date datefrom=dcn.parse(dcn.format(stosearchfromt.getDate()));
                ResultSet df=stmt.executeQuery("select * from salseitem where purchasedate='"+dcn.format(stosearchfromt.getDate())+"'");
                while(df.next()){
                    stosearchmodel.addRow(new Object[]{df.getString(1),df.getString(2),df.getString(3),df.getString(4),df.getString(5),df.getString(6),df.getString(7)});
                }
                if(stosearchtable.getRowCount()==0);
                else{
                    String sto=stosearchmodel.getValueAt(0,2).toString();
                    sto = sto.substring(1, sto.length() - 1);
                    String []stoarray=sto.split(", ");
                    stosearchviewmodel.setRowCount(0);
                    for(int i=0;i<stoarray.length;i++){
                        stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                        i+=2;
                    }
                }
                int tot=0;
                for(int c=0;c<stosearchmodel.getRowCount();c++)
                tot+=Integer.valueOf(stosearchmodel.getValueAt(c,3).toString());
                stosearchtott.setText(String.valueOf(tot+"  "+"Rs"));
            }
            catch(Exception z){
                System.out.println(z);
            }
        }
        else if(stosearchfromt.getDate()==null&&stosearchtot.getDate()!=null){
            JOptionPane.showMessageDialog(this,"Do you want one day's record ? Fill from date field.");
            stosearchtot.setCalendar(null);
        }
        else if(stosearchfromt.getDate()!=null&&stosearchtot.getDate()!=null){
            try{
                java.util.Date fromdate=dcn.parse(dcn.format(stosearchfromt.getDate()));
                java.util.Date todate=dcn.parse(dcn.format(stosearchtot.getDate()));
                if(fromdate.compareTo(todate)<0){
                    ResultSet rm=stmt.executeQuery("select * from salseitem");
                    java.util.Date compdate;
                    while(rm.next()){
                        String sdate=rm.getString(7);
                        compdate=dcn.parse(sdate);
                        if(fromdate.compareTo(compdate)<=0){
                            if(todate.compareTo(compdate)>=0){
                                stosearchmodel.addRow(new Object[]{rm.getString(1),rm.getString(2),rm.getString(3),rm.getString(4),rm.getString(5),rm.getString(6),rm.getString(7)});
                            }
                        }
                    }
                    if(stosearchtable.getRowCount()==0);
                    else{
                        String sto=stosearchmodel.getValueAt(0,2).toString();
                        sto = sto.substring(1, sto.length() - 1);
                        String []stoarray=sto.split(", ");
                        stosearchviewmodel.setRowCount(0);
                        for(int i=0;i<stoarray.length;i++){
                            stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                            i+=2;
                        }
                    }
                    int tot=0;
                    for(int c=0;c<stosearchmodel.getRowCount();c++)
                    tot+=Integer.valueOf(stosearchmodel.getValueAt(c,3).toString());
                    stosearchtott.setText(String.valueOf(tot+"  "+"Rs"));
                }
                else if(fromdate.compareTo(todate)==0){
                    JOptionPane.showMessageDialog(this,"From Date To Date both are same. change the To date field.");
                }
                else{
                    JOptionPane.showMessageDialog(this,"To Date field is lower than From date field. Change the order.");
                }
            }
            catch(Exception p){
                System.out.println(p);
            }
        }
    }//GEN-LAST:event_stosearchActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        if(stosearchmodel.getRowCount()<=0);
        else{
            try {
                stosearchtable.print();
            } catch (PrinterException ex) {
                Logger.getLogger(module2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel hide;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JButton puradd;
    javax.swing.JTable puraddtable;
    private javax.swing.JPanel puraddtablepanel;
    private javax.swing.JTextArea purbill;
    private javax.swing.JPanel purbillpanel;
    private javax.swing.JPanel purbpanel;
    private javax.swing.JTabbedPane purcategory;
    private javax.swing.JButton purclear;
    private javax.swing.JButton purconfirm;
    private javax.swing.JLabel purcustidl;
    private javax.swing.JLabel purcustidt;
    private javax.swing.JLabel purdatel;
    private javax.swing.JLabel purdatet;
    private javax.swing.JLabel purempidl;
    private javax.swing.JLabel purempidt;
    private javax.swing.JLabel purinhaddl;
    private javax.swing.JTextField purinhaddt;
    private javax.swing.JLabel purinhnamel;
    private javax.swing.JLabel purinhnamet;
    private javax.swing.JPanel purinhpanel;
    private javax.swing.JLabel purinhratel;
    private javax.swing.JLabel purinhratet;
    private javax.swing.JLabel puritmaddl;
    private javax.swing.JTextField puritmaddt;
    private javax.swing.JLabel puritmnamel;
    private javax.swing.JLabel puritmnamet;
    private javax.swing.JPanel puritmpanel;
    private javax.swing.JLabel puritmratel;
    private javax.swing.JLabel puritmratet;
    private javax.swing.JLabel purliqaddl;
    private javax.swing.JTextField purliqaddt;
    private javax.swing.JLabel purliqnamel;
    private javax.swing.JLabel purliqnamet;
    private javax.swing.JPanel purliqpanel;
    private javax.swing.JLabel purliqratel;
    private javax.swing.JLabel purliqratet;
    private javax.swing.JLabel purmaill;
    private javax.swing.JPanel purmailpanel;
    private javax.swing.JTextField purmailt;
    private javax.swing.JTabbedPane purmedcategory;
    private javax.swing.JLabel purmedcategoryl;
    private javax.swing.JLabel purmedcategoryt;
    private javax.swing.JButton purprint;
    private javax.swing.JTabbedPane purprintcategory;
    private javax.swing.JButton pursalse;
    private javax.swing.JTabbedPane pursalsecategory;
    private javax.swing.JPanel pursalsedetails;
    private javax.swing.JLabel pursearchl;
    private javax.swing.JTextField pursearcht;
    private javax.swing.JTable pursearchtable;
    private javax.swing.JComboBox<String> purtabaddc;
    private javax.swing.JTextField purtabaddt;
    private javax.swing.JLabel purtabnamel;
    private javax.swing.JLabel purtabnamet;
    private javax.swing.JPanel purtabpanel;
    private javax.swing.JLabel purtabratel;
    private javax.swing.JLabel purtabratet;
    private javax.swing.JLabel purtimel;
    private javax.swing.JLabel purtimet;
    private javax.swing.JLabel purtotl;
    private javax.swing.JLabel purtott;
    private javax.swing.JLabel stocustidt;
    private javax.swing.JLabel stocustmailidt;
    private javax.swing.JLabel stoempidt;
    private javax.swing.JLabel stosalsedatet;
    private javax.swing.JButton stosearch;
    private com.toedter.calendar.JDateChooser stosearchfromt;
    private javax.swing.JPanel stosearchpanel;
    private javax.swing.JTable stosearchtable;
    private com.toedter.calendar.JDateChooser stosearchtot;
    private javax.swing.JLabel stosearchtott;
    private javax.swing.JTable stosearchviewtable;
    private javax.swing.JPanel stotodaypanel;
    private javax.swing.JTable stotodaytable;
    private javax.swing.JLabel stotodaytott;
    private javax.swing.JTable stotodayviewtable;
    // End of variables declaration//GEN-END:variables
}
