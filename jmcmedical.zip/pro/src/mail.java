import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class mail{
    
static void purmail(String custarr[],String to,String custid,String totamount,String empid){
	String recipient=to;
	String from="syedfaizal905@gmail.com";
        String password="pullypqiknffacee";
//String host="localhost";
//Properties properties=System.getProperties();
//properties.setProperty("mail.smtp.host",host);

Properties properties=new Properties();
properties.put("mail.smtp.auth","true");
properties.put("mail.smtp.starttls.enable","true");
properties.put("mail.smtp.host","smtp.gmail.com");
properties.put("mail.smtp.port","587");
//Session session=Session.getDefaultInstance(properties);
Session session=Session.getInstance(properties,new Authenticator(){
@Override
protected PasswordAuthentication getPasswordAuthentication(){
	return new PasswordAuthentication(from,password);
}
});
try{
MimeMessage message=new MimeMessage(session);
message.setFrom(new InternetAddress(from));
message.setRecipient(Message.RecipientType.TO,new InternetAddress(recipient));
message.setSubject("JMC MEDICAL");
String meddetails="Customer Id is : "+custid+"\nEmployee Id is :  "+empid+"   \nPurchase Details from JMC medical \n";
for(int i=0;i<custarr.length;i++){
    
    meddetails=meddetails+custarr[i]+" - "+custarr[i+1]+" it's rate "+custarr[i+2]+" ,\n";
    i=i+2;
}
meddetails=meddetails+"\n"+"Total amount is : "+totamount+"  \n Contact No : 9578342367  \n\t Thanks to purchase here. " ;
message.setText(meddetails);
Transport.send(message);
}
catch(MessagingException mex){
    //System.out.println(mex)
mex.printStackTrace();
}
}
}
   
