import java.awt.Color;
import java.awt.Image;
import java.awt.print.PrinterException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class module2 extends javax.swing.JFrame{
    Connection con;
    Statement stmt;
    DefaultTableModel empmodel2;
    DefaultTableModel empmodel1;
    DefaultTableModel medmodel1;
    DefaultTableModel meddetailmodel1;
    DefaultTableModel stotodaymodel;
    DefaultTableModel stotodayviewmodel;
    DefaultTableModel stosearchmodel;
    DefaultTableModel stosearchviewmodel;
    DefaultTableModel stopensearchmodel;
    DefaultTableModel stopentablemodel;
    SimpleDateFormat dcn=new SimpleDateFormat("yyyy-MM-dd");
    String taboldname="",liqoldname="",inholdname="",itmoldname="";
    public module2() {
        dbconnection();
        initComponents();
        //tabexpireydatet.setSimpleDateFormat("yyyy-MM-dd");
        // ICON IMAGE OF JFRAME
        Image icon=new ImageIcon(this.getClass().getResource("/desktop.png")).getImage();
        this.setIconImage(icon);
         //empmodel1
        empmodel1.addColumn("EMPLOYEE'S ID");
        empmodel1.addColumn("USERNAME");
        empmodel1.addColumn("PASSWORD");
        empmodel1.addColumn("PHONE NO");
        empmodel1.addColumn("MAIL ID");
        empmodel1.addColumn("JOINING DATE");
        empmodel1.addColumn("LAST UPDATE");
        empsearchtable.setOpaque(true);
        empsearchtable.setFillsViewportHeight(true);
        //empmodel2
        empmodel2.addColumn("EMPLOYEE'S ID");
        empmodel2.addColumn("USERNAME");
        empmodel2.addColumn("PASSWORD");
        empmodel2.addColumn("PHONE NO");
        empmodel2.addColumn("MAIL ID");
        empmodel2.addColumn("JOINING DATE");
        empmodel2.addColumn("LAST UPDATE");
        empdetailtable.setOpaque(true);
        empdetailtable.setFillsViewportHeight(true);
        //medmodel1
        medmodel1.addColumn("MEDICINE'SID");
        medmodel1.addColumn("MEDICINE'SNAME");
        medmodel1.addColumn("CATEGORY");
        medmodel1.addColumn("ONCERATE");
        medmodel1.addColumn("SLIPQUANTITY");
        medmodel1.addColumn("SLIPRATE");
        medmodel1.addColumn("ML");
        medmodel1.addColumn("MG");
        medmodel1.addColumn("NUMOFTABLETS");
        medmodel1.addColumn("EXPIREYDATE");
        medmodel1.addColumn("JOINDATE");
        medmodel1.addColumn("LASTUPDATE");
        medsearchtable.setOpaque(true);
        medsearchtable.setFillsViewportHeight(true);
        //meddetailmodel1
        meddetailmodel1.addColumn("MEDICINE'SID");
        meddetailmodel1.addColumn("MEDICINE'SNAME");
        meddetailmodel1.addColumn("CATEGORY");
        meddetailmodel1.addColumn("ONCERATE");
        meddetailmodel1.addColumn("SLIPQUANTITY");
        meddetailmodel1.addColumn("SLIPRATE");
        meddetailmodel1.addColumn("ML");
        meddetailmodel1.addColumn("MG");
        meddetailmodel1.addColumn("NUMOFTABLETS");
        meddetailmodel1.addColumn("EXPIREYDATE");
        meddetailmodel1.addColumn("JOINDATE");
        meddetailmodel1.addColumn("LASTUPDATE");
        meddetailtable.setOpaque(true);
        meddetailtable.setFillsViewportHeight(true);
        //stotodaymodel
        stotodaymodel.addColumn("CUST ID");
        stotodaymodel.addColumn("EMP ID");
        stotodaymodel.addColumn("MEDICINE'S DETAILS");
        stotodaymodel.addColumn("TOT AMOUNT");
        stotodaymodel.addColumn("CUST MAIL-ID");
        stotodaymodel.addColumn("PURCHASE TIME");
        stotodaymodel.addColumn("PURCHASE DATE");
        stotodaytable.setOpaque(true);
        stotodaytable.setFillsViewportHeight(true);
        //stotodayviewmodel
        stotodayviewmodel.addColumn("MEDICINE NAME");
        stotodayviewmodel.addColumn("NUM OF MEDINCE");
        stotodayviewmodel.addColumn("RATE");
        stotodayviewtable.setOpaque(true);
        stotodayviewtable.setFillsViewportHeight(true);
        //stosearchmodel
        stosearchmodel.addColumn("CUST ID");
        stosearchmodel.addColumn("EMP ID");
        stosearchmodel.addColumn("MEDICINE'S DETAILS");
        stosearchmodel.addColumn("TOT AMOUNT");
        stosearchmodel.addColumn("CUST MAIL-ID");
        stosearchmodel.addColumn("PURCHASE TIME");
        stosearchmodel.addColumn("PURCHASE DATE");
        stosearchtable.setOpaque(true);
        stosearchtable.setFillsViewportHeight(true);
        //stosearchviewmodel
        stosearchviewmodel.addColumn("MEDICINE NAME");
        stosearchviewmodel.addColumn("NUM OF MEDINCE");
        stosearchviewmodel.addColumn("RATE");
        stosearchviewtable.setOpaque(true);
        stosearchviewtable.setFillsViewportHeight(true);
        //stopensearchmodel
        stopensearchmodel.addColumn("MEDICINE'SID");
        stopensearchmodel.addColumn("MEDICINE'SNAME");
        stopensearchmodel.addColumn("CATEGORY");
        stopensearchmodel.addColumn("ONCERATE");
        stopensearchmodel.addColumn("SLIPQUANTITY");
        stopensearchmodel.addColumn("SLIPRATE");
        stopensearchmodel.addColumn("ML");
        stopensearchmodel.addColumn("MG");
        stopensearchmodel.addColumn("NUMOFTABLETS");
        stopensearchmodel.addColumn("EXPIREYDATE");
        stopensearchmodel.addColumn("JOINDATE");
        stopensearchmodel.addColumn("LASTUPDATE");
        stopensearchtable.setOpaque(true);
        stopensearchtable.setFillsViewportHeight(true);     
        //stopentablemodel
        stopentablemodel.addColumn("MEDICINE'SID");
        stopentablemodel.addColumn("MEDICINE'SNAME");
        stopentablemodel.addColumn("CATEGORY");
        stopentablemodel.addColumn("ONCERATE");
        stopentablemodel.addColumn("SLIPQUANTITY");
        stopentablemodel.addColumn("SLIPRATE");
        stopentablemodel.addColumn("ML");
        stopentablemodel.addColumn("MG");
        stopentablemodel.addColumn("NUMOFTABLETS");
        stopentablemodel.addColumn("EXPIREYDATE");
        stopentablemodel.addColumn("JOINDATE");
        stopentablemodel.addColumn("LASTUPDATE");
        stopentable.setOpaque(true);
        stopentable.setFillsViewportHeight(true); 
        empdefault();
        empdisplay();
    }  
    private void meddefault(){
        medsearcht.setText("");
         medaddc.setSelectedIndex(0);
         medadd.setVisible(true);
         medsave.setVisible(false);
         meddelete.setVisible(false);
         medcancel.setVisible(false);
         medtabicon.setVisible(true);
         medinhicon.setVisible(false);
         medliqicon.setVisible(false);
         meditmicon.setVisible(false);
         tabletalignment1();
    }
    private String medid(){
         String value="";
        try{
        ResultSet sr=stmt.executeQuery("select medid from medicine");
            int big=0;
            while(sr.next()){
                if(big<Integer.valueOf(sr.getString(1).substring(3)))
                    big=Integer.valueOf(sr.getString(1).substring(3));
            }
            int i;
            for(i=1;i<=big++;i++){
                int count=0;
                ResultSet s=stmt.executeQuery("select medid from medicine");
                while(s.next()){
                    if(i==Integer.valueOf(s.getString(1).substring(3))){
                        count++;
                        break;
                }
            }
            if(count==1)
                continue;
            else 
                break;
            }
            value="med"+i;
        }
        catch(SQLException j){
            System.out.println(j);
        }
        return value;
    }
    private void stopendefault(){
        try{
            ResultSet ry=stmt.executeQuery("select * from medicine where numofmedicines <=300");
            stopentablemodel.setRowCount(0);
            while(ry.next())
                stopentablemodel.addRow(new Object[]{ry.getString(1),ry.getString(2),ry.getString(3),ry.getString(4),ry.getString(5),ry.getString(6),ry.getString(7),ry.getString(8),ry.getString(9),ry.getString(10),ry.getString(11),ry.getString(12)});                  
            String category=stopentablemodel.getValueAt(0,2).toString();
            if(category.equals("TABLETS")){
                stopencategory.setSelectedIndex(0);
                stopenmedidt.setText(stopentablemodel.getValueAt(0, 0).toString());
                stopenmednamet.setText(stopentablemodel.getValueAt(0, 1).toString());
                stopenmedcategoryt.setText(stopentablemodel.getValueAt(0,2).toString());
                stopentabexistingt.setText(stopentablemodel.getValueAt(0,8).toString());
                stopentabaddc.setSelectedIndex(0);
                stopentabaddt.setText("");
                stopentabactualt.setText("0");
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopentablemodel.getValueAt(0, 9));
                    stopentabexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
            }
            else{
                stopencategory.setSelectedIndex(1);
                stopenmedidt.setText(stopentablemodel.getValueAt(0,0).toString());
                stopenmednamet.setText(stopentablemodel.getValueAt(0,1).toString());
                stopenmedcategoryt.setText(stopentablemodel.getValueAt(0, 2).toString());
                stopenothexistingt.setText(stopentablemodel.getValueAt(0,8).toString());
                stopenothaddt.setText("");
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopentablemodel.getValueAt(0, 9));
                    stopenothexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
            }
        }
        catch(Exception j){
        System.out.println(j);
        }
    }
    private void tabletalignment1(){
        medheadline.setText("ADD TABLET'S DETAILS");
        tabidl.setBounds(0,0,100,25);
        tabidt.setBounds(125,0,75,23);
        tabnamel.setBounds(225,0,100,25);
        tabnamet.setBounds(350,0,75,23);
        tabnamet.setText("");
        tabonceratel.setBounds(450,0,100,25);
        tabonceratet.setBounds(575,0,75,23);
        tabonceratet.setText("");
        tabslipquantityl.setBounds(0,50,100,25);
        tabslipquantityt.setBounds(125,50,75,23);
        tabslipquantityt.setText("");
        tabslipratel.setBounds(225,50,100,25);
        tabslipratet.setBounds(350,50,75,23);
        tabslipratet.setText("");
        tabexpireydatel.setBounds(450,50,100,25);
        tabexpireydatet.setBounds(550,50,120,23);
        tabexpireydatet.setCalendar(null);
        tabaddtabletsl.setBounds(0,100,100,25);
        tabaddtabletsc.setBounds(125,100,75,25);
        tabaddtabletst.setBounds(225,100,75,23);
        tabaddtabletst.setText("");
        tabjoindatel.setBounds(350,100,100,25);
        tabjoindatet.setBounds(475,100,100,23);
        tabjoindatet.setText(java.time.LocalDate.now().toString());
        tabactualtabletsl.setBounds(0,150,100,25);
        tabactualtabletst.setBounds(125,150,75,23);
        tabactualtabletst.setText("0");
        tablastupdatel.setVisible(false);
        tablastupdatet.setVisible(false);
        tablastupdatet.setText("NULL");
        tabexistingtabletsl.setVisible(false);
        tabexistingtabletst.setVisible(false);
        tabexistingtabletst.setText("");
        tabidt.setText(medid());
    }
    private void tabletalignment2(){
        medheadline.setText("UPDATE THE TABLET'S DETAILS");
        tabexistingtabletsl.setBounds(0,100,100,25);
        tabexistingtabletst.setBounds(125,100,75,23);
        tabjoindatel.setBounds(225,100,100,25);
        tabjoindatet.setBounds(350,100,100,23);
        tablastupdatel.setBounds(450,100,100,25);
        tablastupdatet.setBounds(575,100,100,23);
        tabaddtabletsl.setBounds(0,150,100,25);
        tabaddtabletsc.setBounds(125,150,75,25);
        tabaddtabletst.setBounds(225,150,75,23);
        tabactualtabletsl.setBounds(350,150,100,25);
        tabactualtabletst.setBounds(475,150,75,23);
        tablastupdatel.setVisible(true);
        tablastupdatet.setVisible(true);
        tabexistingtabletsl.setVisible(true);
        tabexistingtabletst.setVisible(true);
        medadd.setVisible(false);
        medsave.setVisible(true);
        medcancel.setVisible(true);
        meddelete.setVisible(true);
    }
    private void liquidalignment1(){
        medheadline.setText("ADD LIQUID'S DETAILS");
        liqidl.setBounds(0,0,100,25);
        liqidt.setBounds(125,0,75,23);
        liqnamel.setBounds(225,0,100,25);
        liqnamet.setBounds(350,0,75,23);
        liqnamet.setText("");
        liqmll.setBounds(450,0,100,25);
        liqmlt.setBounds(575,0,75,23);
        liqmlt.setText("");
        liqonceratel.setBounds(0,50,100,25);
        liqonceratet.setBounds(125,50,75,23);
        liqonceratet.setText("");
        liqexpireydatel.setBounds(225,50,80,25);
        liqexpireydatet.setBounds(330,50,100,23);
        liqexpireydatet.setCalendar(null);
        liqjoindatel.setBounds(450,50,100,25);
        liqjoindatet.setBounds(575,50,100,23);
        liqjoindatet.setText(java.time.LocalDate.now().toString());
        liqaddl.setBounds(0,100,100,25);
        liqaddt.setBounds(125,100,75,23);
        liqaddt.setText("");
        liqlastupdatel.setVisible(false);
        liqlastupdatet.setVisible(false);
        liqexistingliquidl.setVisible(false);
        liqexistingliquidt.setVisible(false);
        liqidt.setText(medid());
        medadd.setVisible(true);
        medsave.setVisible(false);
        meddelete.setVisible(false);
        medcancel.setVisible(false);
    }
    private void liquidalignment2(){
        medheadline.setText("UPDATE THE LIQUID'S DETAILS");
        liqexistingliquidl.setBounds(450,50,100,25);
        liqexistingliquidt.setBounds(575,50,75,23);
        liqjoindatel.setBounds(0,100,100,25);
        liqjoindatet.setBounds(125,100,100,23);
        liqlastupdatel.setBounds(225,100,80,25);
        liqlastupdatet.setBounds(350,100,100,23);
        liqaddl.setBounds(450,100,100,25);
        liqaddt.setBounds(575,100,75,23);
        liqaddl.setText("ADD MORE LIQUIDS");
        liqlastupdatel.setVisible(true);
        liqlastupdatet.setVisible(true);
        liqexistingliquidl.setVisible(true);
        liqexistingliquidt.setVisible(true);
        medadd.setVisible(false);
        medsave.setVisible(true);
        meddelete.setVisible(true);
        medcancel.setVisible(true);
    }
    private void inhaleralignment1(){
            medheadline.setText("ADD INHALER'S DETAILS");
        inhidl.setBounds(0,0,100,25);
        inhidt.setBounds(125,0,75,23);
        inhnamel.setBounds(225,0,100,25);
        inhnamet.setBounds(350,0,75,23);
        inhnamet.setText("");
        inhmgl.setBounds(450,0,100,25);
        inhmgt.setBounds(575,0,75,23);
        inhmgt.setText("");
        inhonceratel.setBounds(0,50,100,25);
        inhonceratet.setBounds(125,50,75,23);
        inhonceratet.setText("");
        inhexpireydatel.setBounds(225,50,80,25);
        inhexpireydatet.setBounds(330,50,100,25);
        inhexpireydatet.setCalendar(null);
        inhjoindatel.setBounds(450,50,100,25);
        inhjoindatet.setBounds(575,50,100,23);
        inhjoindatet.setText(java.time.LocalDate.now().toString());
        inhaddl.setBounds(0,100,100,25);
        inhaddt.setBounds(125,100,75,23);
        inhaddt.setText("");
        inhidt.setText(medid());
        inhlastupdatel.setVisible(false);
        inhlastupdatet.setVisible(false);
        inhexistingl.setVisible(false);
        inhexistingt.setVisible(false);
        medadd.setVisible(true);
        medsave.setVisible(false);
        meddelete.setVisible(false);
        medcancel.setVisible(false);
    }
    private void inhaleralignment2(){
         medheadline.setText("UPDATE THE INHALER'S DETAILS");
        inhexistingl.setBounds(450,50,100,25);
        inhexistingt.setBounds(575,50,75,23);
        inhjoindatel.setBounds(0,100,100,25);
        inhjoindatet.setBounds(125,100,100,23);
        inhlastupdatel.setBounds(225,100,80,25);
        inhlastupdatet.setBounds(350,100,100,23);
        inhaddl.setBounds(450,100,100,25);
        inhaddt.setBounds(575,100,75,23);
        inhaddl.setText("ADD MORE INHALER");
        inhlastupdatel.setVisible(true);
        inhlastupdatet.setVisible(true);
        inhexistingl.setVisible(true);
        inhexistingt.setVisible(true);
        medadd.setVisible(false);
        medsave.setVisible(true);
        meddelete.setVisible(true);
        medcancel.setVisible(true);
    }
    private void otheralignment1(){
      medheadline.setText("ADD ITEM'S DETAILS");
        itmidl.setBounds(0,0,100,25);
        itmidt.setBounds(125,0,75,23);
        itmnamel.setBounds(225,0,100,25);
        itmnamet.setBounds(350,0,75,23);
        itmnamet.setText("");
        itmonceratel.setBounds(450,0,100,25);
        itmonceratet.setBounds(575,0,75,23);
        itmonceratet.setText("");
        itmexpireydatel.setBounds(0,50,100,25);
        itmexpireydatet.setBounds(100,50,100,25);
        itmexpireydatet.setCalendar(null);
        itmjoindatel.setBounds(225,50,100,25);
        itmjoindatet.setBounds(350,50,100,23);
        itmjoindatet.setText(java.time.LocalDate.now().toString());
        itmaddl.setBounds(450,50,100,25);
        itmaddt.setBounds(575,50,75,23);
        itmaddt.setText("");
        itmidt.setText(medid());
        itmlastupdatel.setVisible(false);
        itmlastupdatet.setVisible(false);
        itmexistingl.setVisible(false);
        itmexistingt.setVisible(false);
        medadd.setVisible(true);
        medsave.setVisible(false);
        meddelete.setVisible(false);
        medcancel.setVisible(false);
        
    }
    private void otheralignment2(){
        medheadline.setText("UPDATE ITEM'S DETAILS");
        itmexistingl.setBounds(225,50,100,25);
        itmexistingt.setBounds(350,50,75,25);
        itmjoindatel.setBounds(450,50,100,25);
        itmjoindatet.setBounds(575,50,100,23);
        itmlastupdatel.setBounds(0,100,100,25);
        itmlastupdatet.setBounds(125,100,100,23);
        itmaddl.setBounds(225,100,100,25);
        itmaddl.setText("ADD MORE ITEM");
        itmaddt.setBounds(350,100,75,23);
        itmlastupdatel.setVisible(true);
        itmlastupdatet.setVisible(true);
        itmexistingl.setVisible(true);
        itmexistingt.setVisible(true);
        medadd.setVisible(false);
        medsave.setVisible(true);
        meddelete.setVisible(true);
        medcancel.setVisible(true);
    }
    private void empdefault(){
        empaddheadline.setText("ADD TABLET'S DETAILS");
        empusernamet.setText("");
        emppasswordt.setText("");
        empphonet.setText("");
        empmailt.setText("NULL");
        empjoindatet.setText(java.time.LocalDate.now().toString());
        emplastupdatel.setVisible(false);
        emplastupdatet.setVisible(false);
        emplastupdatet.setText("NULL");
        empadd.setVisible(true);
        empsave.setVisible(false);
        empdelete.setVisible(false);
        empcancel.setVisible(false);
        try{
        ResultSet sr=stmt.executeQuery("select Eid from employee");
            int big=0,i;
            while(sr.next()){
                if(big<Integer.valueOf(sr.getString(1).substring(3)))
                    big=Integer.valueOf(sr.getString(1).substring(3));
            }
            for(i=1;i<=big++;i++){
            int count=0;
            ResultSet s=stmt.executeQuery("select Eid from employee");
            while(s.next()){
                if(i==Integer.valueOf(s.getString(1).substring(3))){
                    count++;
                    break;
                }
            }
            if(count==1)
                continue;
            else
                break;
            }
            empidt.setText("emp"+i);
        }
        catch(Exception j){
            System.out.println(j);
        }
    }
    private void empdisplay(){
        try{
        empdetailtable.setEnabled(false);
        ResultSet rs=stmt.executeQuery("select * from employee order by Eid asc");
        empmodel2.setRowCount(0);
        while(rs.next())
                empmodel2.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)});           
            }
        catch(Exception j){
            System.out.println(j);
        }
    }
    private void dbconnection(){
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
       con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical","root","");
        stmt=con.createStatement();
    }
        catch(ClassNotFoundException | SQLException z){
           JOptionPane.showMessageDialog(this,"Check Datebase Connection..");
             System.exit(0);
        }
    }
    private void meddisplay(){
        try{
            meddetailtable.setEnabled(false);
            ResultSet rx=stmt.executeQuery("select * from medicine order by medid asc");
            meddetailmodel1.setRowCount(0);
            while(rx.next())
                meddetailmodel1.addRow(new Object[]{rx.getString(1),rx.getString(2),rx.getString(3),rx.getInt(4),rx.getInt(5),rx.getInt(6),rx.getInt(7),rx.getInt(8),rx.getInt(9),rx.getString(10),rx.getString(11),rx.getString(12)});
        }
        catch(Exception j){
            System.out.println(j);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        back = new javax.swing.JButton();
        employeedetails = new javax.swing.JButton();
        medicinedetails = new javax.swing.JButton();
        stockdetails = new javax.swing.JButton();
        servercategory = new javax.swing.JTabbedPane();
        emppagepanel = new javax.swing.JPanel();
        emppageheadline = new javax.swing.JLabel();
        empsearchl = new javax.swing.JLabel();
        empsearcht = new javax.swing.JTextField();
        employeelist = new javax.swing.JButton();
        empaddheadline = new javax.swing.JLabel();
        empidl = new javax.swing.JLabel();
        empusernamel = new javax.swing.JLabel();
        empusernamet = new javax.swing.JTextField();
        emppasswordl = new javax.swing.JLabel();
        emppasswordt = new javax.swing.JTextField();
        empjoindatel = new javax.swing.JLabel();
        empjoindatet = new javax.swing.JLabel();
        emplastupdatel = new javax.swing.JLabel();
        emplastupdatet = new javax.swing.JLabel();
        empsave = new javax.swing.JButton();
        empadd = new javax.swing.JButton();
        empdelete = new javax.swing.JButton();
        empcancel = new javax.swing.JButton();
        jsp1 = new javax.swing.JScrollPane();
        empsearchtable = new javax.swing.JTable();
        empidt = new javax.swing.JLabel();
        empphonel = new javax.swing.JLabel();
        empphonet = new javax.swing.JTextField();
        empmaill = new javax.swing.JLabel();
        empmailt = new javax.swing.JTextField();
        empdetailpanel = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        empdetailtable = new javax.swing.JTable();
        gotoemp = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        medpagepanel = new javax.swing.JPanel();
        medicinepageheadline = new javax.swing.JLabel();
        medicinelist = new javax.swing.JButton();
        medsearcht = new javax.swing.JTextField();
        medaddc = new javax.swing.JComboBox<>();
        medheadline = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        meddelete = new javax.swing.JButton();
        medsave = new javax.swing.JButton();
        medadd = new javax.swing.JButton();
        medcancel = new javax.swing.JButton();
        medjsp1 = new javax.swing.JScrollPane();
        medsearchtable = new javax.swing.JTable();
        medservercategory = new javax.swing.JTabbedPane();
        tabletpanel = new javax.swing.JPanel();
        tabnamel = new javax.swing.JLabel();
        tabnamet = new javax.swing.JTextField();
        tabidl = new javax.swing.JLabel();
        tabidt = new javax.swing.JLabel();
        tabonceratel = new javax.swing.JLabel();
        tabslipquantityl = new javax.swing.JLabel();
        tabslipratel = new javax.swing.JLabel();
        tabjoindatel = new javax.swing.JLabel();
        tabjoindatet = new javax.swing.JLabel();
        tablastupdatel = new javax.swing.JLabel();
        tabaddtabletsl = new javax.swing.JLabel();
        tabaddtabletsc = new javax.swing.JComboBox<>();
        tabactualtabletsl = new javax.swing.JLabel();
        tabactualtabletst = new javax.swing.JLabel();
        tabexistingtabletsl = new javax.swing.JLabel();
        tabexistingtabletst = new javax.swing.JLabel();
        tabexpireydatel = new javax.swing.JLabel();
        tabexpireydatet = new com.toedter.calendar.JDateChooser();
        tabslipquantityt = new javax.swing.JTextField();
        tabslipratet = new javax.swing.JTextField();
        tabonceratet = new javax.swing.JTextField();
        tabaddtabletst = new javax.swing.JTextField();
        tablastupdatet = new javax.swing.JLabel();
        liquidpanel = new javax.swing.JPanel();
        liqidl = new javax.swing.JLabel();
        liqnamel = new javax.swing.JLabel();
        liqnamet = new javax.swing.JTextField();
        liqonceratel = new javax.swing.JLabel();
        liqmll = new javax.swing.JLabel();
        liqexpireydatel = new javax.swing.JLabel();
        liqexpireydatet = new com.toedter.calendar.JDateChooser();
        liqjoindatel = new javax.swing.JLabel();
        liqaddl = new javax.swing.JLabel();
        liqlastupdatel = new javax.swing.JLabel();
        liqexistingliquidl = new javax.swing.JLabel();
        liqonceratet = new javax.swing.JTextField();
        liqaddt = new javax.swing.JTextField();
        liqmlt = new javax.swing.JTextField();
        liqjoindatet = new javax.swing.JLabel();
        liqlastupdatet = new javax.swing.JLabel();
        liqexistingliquidt = new javax.swing.JLabel();
        liqidt = new javax.swing.JLabel();
        inhalerspanel = new javax.swing.JPanel();
        inhidl = new javax.swing.JLabel();
        inhnamel = new javax.swing.JLabel();
        inhnamet = new javax.swing.JTextField();
        inhmgl = new javax.swing.JLabel();
        inhmgt = new javax.swing.JTextField();
        inhonceratel = new javax.swing.JLabel();
        inhonceratet = new javax.swing.JTextField();
        inhexpireydatel = new javax.swing.JLabel();
        inhexpireydatet = new com.toedter.calendar.JDateChooser();
        inhjoindatel = new javax.swing.JLabel();
        inhlastupdatel = new javax.swing.JLabel();
        inhexistingl = new javax.swing.JLabel();
        inhaddl = new javax.swing.JLabel();
        inhaddt = new javax.swing.JTextField();
        inhidt = new javax.swing.JLabel();
        inhjoindatet = new javax.swing.JLabel();
        inhlastupdatet = new javax.swing.JLabel();
        inhexistingt = new javax.swing.JLabel();
        otherpanel = new javax.swing.JPanel();
        itmidl = new javax.swing.JLabel();
        itmidt = new javax.swing.JLabel();
        itmnamel = new javax.swing.JLabel();
        itmnamet = new javax.swing.JTextField();
        itmonceratel = new javax.swing.JLabel();
        itmonceratet = new javax.swing.JTextField();
        itmjoindatel = new javax.swing.JLabel();
        itmjoindatet = new javax.swing.JLabel();
        itmlastupdatel = new javax.swing.JLabel();
        itmlastupdatet = new javax.swing.JLabel();
        itmexpireydatel = new javax.swing.JLabel();
        itmexpireydatet = new com.toedter.calendar.JDateChooser();
        itmaddl = new javax.swing.JLabel();
        itmaddt = new javax.swing.JTextField();
        itmexistingl = new javax.swing.JLabel();
        itmexistingt = new javax.swing.JLabel();
        medtabicon = new javax.swing.JLabel();
        medinhicon = new javax.swing.JLabel();
        meditmicon = new javax.swing.JLabel();
        medliqicon = new javax.swing.JLabel();
        meddetailspage = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        meddetailtable = new javax.swing.JTable();
        medgotomed = new javax.swing.JButton();
        stockspage = new javax.swing.JPanel();
        stotodayb = new javax.swing.JButton();
        stosearchb = new javax.swing.JButton();
        stopendingb = new javax.swing.JButton();
        stocategory = new javax.swing.JTabbedPane();
        stotodaypanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        stotodaytable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        stotodayviewtable = new javax.swing.JTable();
        stocustidt = new javax.swing.JLabel();
        stoempidt = new javax.swing.JLabel();
        stosalsedatet = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        stocustmailidt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        stotodaytott = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        stosearchpanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        stosearchtable = new javax.swing.JTable();
        stosearchtot = new com.toedter.calendar.JDateChooser();
        stosearchfromt = new com.toedter.calendar.JDateChooser();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        stosearch = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        stosearchtott = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        stosearchviewtable = new javax.swing.JTable();
        stopendingpanel = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        stopensearcht = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        stopensearchtable = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        stopentable = new javax.swing.JTable();
        stopenupdate = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        stopencategory = new javax.swing.JTabbedPane();
        stopentabpanel = new javax.swing.JPanel();
        stopentabexistingl = new javax.swing.JLabel();
        stopentabexistingt = new javax.swing.JLabel();
        stopentabaddc = new javax.swing.JComboBox<>();
        stopentabaddl = new javax.swing.JLabel();
        stopentabaddt = new javax.swing.JTextField();
        stopentabactuall = new javax.swing.JLabel();
        stopentabactualt = new javax.swing.JLabel();
        stopentabexpireydatet = new com.toedter.calendar.JDateChooser();
        stopentabexpireyl = new javax.swing.JLabel();
        stopenotherpanel = new javax.swing.JPanel();
        stopenothexistingl = new javax.swing.JLabel();
        stopenothexistingt = new javax.swing.JLabel();
        stopenothaddl = new javax.swing.JLabel();
        stopenothaddt = new javax.swing.JTextField();
        stopenothexpireydatel = new javax.swing.JLabel();
        stopenothexpireydatet = new com.toedter.calendar.JDateChooser();
        stopenmedidl = new javax.swing.JLabel();
        stopenmedidt = new javax.swing.JLabel();
        stopenmednamel = new javax.swing.JLabel();
        stopenmednamet = new javax.swing.JLabel();
        stopencategoryl = new javax.swing.JLabel();
        stopenmedcategoryt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SERVE SIDE OF JMC MEDICAL");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        back.setBackground(new java.awt.Color(128, 123, 123));
        back.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 255));
        back.setText("BACK");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(46, 34, 91, 30);

        employeedetails.setBackground(new java.awt.Color(128, 123, 123));
        employeedetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        employeedetails.setForeground(new java.awt.Color(255, 255, 255));
        employeedetails.setText("EMPLOYEE DETAILS");
        employeedetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeedetailsActionPerformed(evt);
            }
        });
        jPanel1.add(employeedetails);
        employeedetails.setBounds(223, 34, 158, 30);

        medicinedetails.setBackground(new java.awt.Color(128, 123, 123));
        medicinedetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        medicinedetails.setForeground(new java.awt.Color(255, 255, 255));
        medicinedetails.setText("MEDICINE DETAILS");
        medicinedetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medicinedetailsActionPerformed(evt);
            }
        });
        jPanel1.add(medicinedetails);
        medicinedetails.setBounds(459, 34, 153, 30);

        stockdetails.setBackground(new java.awt.Color(128, 123, 123));
        stockdetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockdetails.setForeground(new java.awt.Color(255, 255, 255));
        stockdetails.setText("STOCK DETAILS");
        stockdetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockdetailsActionPerformed(evt);
            }
        });
        jPanel1.add(stockdetails);
        stockdetails.setBounds(687, 34, 133, 30);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 90));

        emppagepanel.setBackground(new java.awt.Color(120, 185, 170));
        emppagepanel.setLayout(null);

        emppageheadline.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        emppageheadline.setForeground(new java.awt.Color(255, 255, 255));
        emppageheadline.setText("EMPLOYEE'S DETAILS");
        emppagepanel.add(emppageheadline);
        emppageheadline.setBounds(310, 20, 190, 25);

        empsearchl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empsearchl.setForeground(new java.awt.Color(255, 255, 255));
        empsearchl.setText("ENTER EMPLOYEE'S ID TO SEARCH");
        emppagepanel.add(empsearchl);
        empsearchl.setBounds(210, 70, 220, 25);

        empsearcht.setBackground(new java.awt.Color(120, 185, 170));
        empsearcht.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        empsearcht.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                empsearchtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                empsearchtKeyTyped(evt);
            }
        });
        emppagepanel.add(empsearcht);
        empsearcht.setBounds(440, 70, 150, 20);

        employeelist.setBackground(new java.awt.Color(128, 123, 123));
        employeelist.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        employeelist.setForeground(new java.awt.Color(255, 255, 255));
        employeelist.setText("EMPLOYEE'S LIST");
        employeelist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeelistActionPerformed(evt);
            }
        });
        emppagepanel.add(employeelist);
        employeelist.setBounds(691, 30, 130, 31);

        empaddheadline.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        empaddheadline.setForeground(new java.awt.Color(255, 255, 255));
        empaddheadline.setText("ADD EMPLOYEE'S DETAILS");
        emppagepanel.add(empaddheadline);
        empaddheadline.setBounds(330, 210, 180, 30);

        empidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empidl.setText("EMPLOYEE'S ID :");
        emppagepanel.add(empidl);
        empidl.setBounds(80, 270, 100, 20);

        empusernamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empusernamel.setText("USERNAME :");
        emppagepanel.add(empusernamel);
        empusernamel.setBounds(340, 270, 90, 20);

        empusernamet.setBackground(new java.awt.Color(120, 185, 170));
        empusernamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        empusernamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        empusernamet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empusernametActionPerformed(evt);
            }
        });
        emppagepanel.add(empusernamet);
        empusernamet.setBounds(430, 270, 120, 20);

        emppasswordl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        emppasswordl.setText("PASSWORD :");
        emppagepanel.add(emppasswordl);
        emppasswordl.setBounds(600, 270, 90, 20);

        emppasswordt.setBackground(new java.awt.Color(120, 185, 170));
        emppasswordt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        emppasswordt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        emppasswordt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emppasswordtActionPerformed(evt);
            }
        });
        emppagepanel.add(emppasswordt);
        emppasswordt.setBounds(690, 270, 110, 20);

        empjoindatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empjoindatel.setText("JOINING DATE :");
        emppagepanel.add(empjoindatel);
        empjoindatel.setBounds(590, 350, 100, 20);
        emppagepanel.add(empjoindatet);
        empjoindatet.setBounds(700, 350, 110, 20);

        emplastupdatel.setText("LAST UPDATE :");
        emppagepanel.add(emplastupdatel);
        emplastupdatel.setBounds(670, 220, 90, 20);
        emppagepanel.add(emplastupdatet);
        emplastupdatet.setBounds(760, 220, 80, 20);

        empsave.setBackground(new java.awt.Color(128, 123, 123));
        empsave.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empsave.setForeground(new java.awt.Color(255, 255, 255));
        empsave.setText("SAVE");
        empsave.setBorder(null);
        empsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empsaveActionPerformed(evt);
            }
        });
        emppagepanel.add(empsave);
        empsave.setBounds(150, 420, 130, 40);

        empadd.setBackground(new java.awt.Color(128, 123, 123));
        empadd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empadd.setForeground(new java.awt.Color(255, 255, 255));
        empadd.setText("ADD EMPLOYEE");
        empadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empaddActionPerformed(evt);
            }
        });
        emppagepanel.add(empadd);
        empadd.setBounds(380, 420, 130, 40);

        empdelete.setBackground(new java.awt.Color(128, 123, 123));
        empdelete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empdelete.setForeground(new java.awt.Color(255, 255, 255));
        empdelete.setText("DELETE");
        empdelete.setPreferredSize(new java.awt.Dimension(75, 22));
        empdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empdeleteActionPerformed(evt);
            }
        });
        emppagepanel.add(empdelete);
        empdelete.setBounds(380, 420, 130, 40);

        empcancel.setBackground(new java.awt.Color(128, 123, 123));
        empcancel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empcancel.setForeground(new java.awt.Color(255, 255, 255));
        empcancel.setText("CANCEL");
        empcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empcancelActionPerformed(evt);
            }
        });
        emppagepanel.add(empcancel);
        empcancel.setBounds(610, 420, 130, 40);

        empsearchtable.setBackground(new java.awt.Color(255, 102, 102));
        empmodel1=new DefaultTableModel();
        empsearchtable.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        empsearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empsearchtable.setForeground(new java.awt.Color(255, 255, 255));
        empsearchtable.setModel(empmodel1);
        empsearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                empsearchtableMouseClicked(evt);
            }
        });
        jsp1.setViewportView(empsearchtable);

        emppagepanel.add(jsp1);
        jsp1.setBounds(60, 110, 760, 90);

        empidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        emppagepanel.add(empidt);
        empidt.setBounds(200, 270, 80, 20);

        empphonel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empphonel.setText("EMP PHONE NO :");
        emppagepanel.add(empphonel);
        empphonel.setBounds(80, 350, 100, 20);

        empphonet.setBackground(new java.awt.Color(120, 185, 170));
        empphonet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        empphonet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        empphonet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empphonetActionPerformed(evt);
            }
        });
        empphonet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                empphonetKeyTyped(evt);
            }
        });
        emppagepanel.add(empphonet);
        empphonet.setBounds(190, 350, 120, 20);

        empmaill.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empmaill.setText("EMP MAIN ID :");
        emppagepanel.add(empmaill);
        empmaill.setBounds(330, 350, 100, 16);

        empmailt.setBackground(new java.awt.Color(120, 185, 170));
        empmailt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        empmailt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        empmailt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empmailtActionPerformed(evt);
            }
        });
        emppagepanel.add(empmailt);
        empmailt.setBounds(430, 350, 130, 20);

        servercategory.addTab("tab1", emppagepanel);

        empdetailpanel.setBackground(new java.awt.Color(120, 185, 170));
        empdetailpanel.setLayout(null);

        empmodel2=new DefaultTableModel();
        empdetailtable.setBackground(new java.awt.Color(255, 102, 102));
        empdetailtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        empdetailtable.setForeground(new java.awt.Color(255, 255, 255));
        empdetailtable.setModel(empmodel2);
        jScrollPane7.setViewportView(empdetailtable);

        empdetailpanel.add(jScrollPane7);
        jScrollPane7.setBounds(22, 86, 826, 370);

        gotoemp.setBackground(new java.awt.Color(128, 123, 123));
        gotoemp.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        gotoemp.setForeground(new java.awt.Color(255, 255, 255));
        gotoemp.setText("GO TO EMP PAGE");
        gotoemp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gotoempActionPerformed(evt);
            }
        });
        empdetailpanel.add(gotoemp);
        gotoemp.setBounds(711, 23, 137, 30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("JMC EMPLOYEES LIST");
        empdetailpanel.add(jLabel5);
        jLabel5.setBounds(330, 30, 200, 30);

        servercategory.addTab("tab5", empdetailpanel);

        medpagepanel.setBackground(new java.awt.Color(120, 185, 170));
        medpagepanel.setLayout(null);

        medicinepageheadline.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        medicinepageheadline.setForeground(new java.awt.Color(255, 255, 255));
        medicinepageheadline.setText("MEDICINES PAGE");
        medpagepanel.add(medicinepageheadline);
        medicinepageheadline.setBounds(350, 10, 149, 25);

        medicinelist.setBackground(new java.awt.Color(128, 123, 123));
        medicinelist.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medicinelist.setForeground(new java.awt.Color(255, 255, 255));
        medicinelist.setText("MEDICINE'S LIST");
        medicinelist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medicinelistActionPerformed(evt);
            }
        });
        medpagepanel.add(medicinelist);
        medicinelist.setBounds(720, 30, 127, 31);

        medsearcht.setBackground(new java.awt.Color(120, 185, 170));
        medsearcht.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        medsearcht.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        medsearcht.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        medsearcht.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                medsearchtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                medsearchtKeyTyped(evt);
            }
        });
        medpagepanel.add(medsearcht);
        medsearcht.setBounds(407, 52, 140, 20);

        medaddc.setBackground(new java.awt.Color(255, 102, 102));
        medaddc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TABLETS", "LIQUID", "INHALERS", "OTHERS" }));
        medaddc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                medaddcItemStateChanged(evt);
            }
        });
        medpagepanel.add(medaddc);
        medaddc.setBounds(110, 200, 110, 22);

        medheadline.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        medheadline.setForeground(new java.awt.Color(255, 255, 255));
        medheadline.setText("ENTER THE TABLET'S DETAILS");
        medpagepanel.add(medheadline);
        medheadline.setBounds(390, 200, 250, 20);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ENTER THE MEDICINES NAME TO SEARCH :");
        medpagepanel.add(jLabel2);
        jLabel2.setBounds(140, 56, 250, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("MEDICINE TYPE");
        medpagepanel.add(jLabel3);
        jLabel3.setBounds(20, 200, 90, 20);

        meddelete.setBackground(new java.awt.Color(128, 123, 123));
        meddelete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        meddelete.setForeground(new java.awt.Color(255, 255, 255));
        meddelete.setText("DELETE");
        meddelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meddeleteActionPerformed(evt);
            }
        });
        medpagepanel.add(meddelete);
        meddelete.setBounds(470, 460, 90, 30);

        medsave.setBackground(new java.awt.Color(128, 123, 123));
        medsave.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medsave.setForeground(new java.awt.Color(255, 255, 255));
        medsave.setText("SAVE");
        medsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medsaveActionPerformed(evt);
            }
        });
        medpagepanel.add(medsave);
        medsave.setBounds(310, 460, 100, 30);

        medadd.setBackground(new java.awt.Color(128, 123, 123));
        medadd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medadd.setForeground(new java.awt.Color(255, 255, 255));
        medadd.setText("ADD");
        medadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medaddActionPerformed(evt);
            }
        });
        medpagepanel.add(medadd);
        medadd.setBounds(470, 460, 90, 30);

        medcancel.setBackground(new java.awt.Color(128, 123, 123));
        medcancel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medcancel.setForeground(new java.awt.Color(255, 255, 255));
        medcancel.setText("CANCEL");
        medcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medcancelActionPerformed(evt);
            }
        });
        medpagepanel.add(medcancel);
        medcancel.setBounds(620, 460, 90, 30);

        medmodel1=new DefaultTableModel();
        medsearchtable.setBackground(new java.awt.Color(255, 102, 102));
        medsearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medsearchtable.setForeground(new java.awt.Color(255, 255, 255));
        medsearchtable.setModel(medmodel1);
        medsearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                medsearchtableMouseClicked(evt);
            }
        });
        medjsp1.setViewportView(medsearchtable);

        medpagepanel.add(medjsp1);
        medjsp1.setBounds(10, 90, 850, 90);

        medservercategory.setTabPlacement(javax.swing.JTabbedPane.RIGHT);

        tabletpanel.setBackground(new java.awt.Color(120, 185, 170));
        tabletpanel.setLayout(null);

        tabnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabnamel.setText("TABLET'S NAME ");
        tabletpanel.add(tabnamel);
        tabnamel.setBounds(250, 30, 100, 16);

        tabnamet.setBackground(new java.awt.Color(120, 185, 170));
        tabnamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabnamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tabletpanel.add(tabnamet);
        tabnamet.setBounds(350, 30, 76, 22);

        tabidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabidl.setText("TABLET'S ID");
        tabletpanel.add(tabidl);
        tabidl.setBounds(40, 30, 90, 16);

        tabidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabletpanel.add(tabidt);
        tabidt.setBounds(140, 30, 80, 20);

        tabonceratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabonceratel.setText("ONCE RATE");
        tabletpanel.add(tabonceratel);
        tabonceratel.setBounds(450, 30, 86, 16);

        tabslipquantityl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabslipquantityl.setText("SLIP QUANTITY");
        tabletpanel.add(tabslipquantityl);
        tabslipquantityl.setBounds(40, 70, 87, 16);

        tabslipratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabslipratel.setText("SLIP RATE");
        tabletpanel.add(tabslipratel);
        tabslipratel.setBounds(260, 70, 56, 16);

        tabjoindatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabjoindatel.setText("JOIN DATE ");
        tabletpanel.add(tabjoindatel);
        tabjoindatel.setBounds(30, 110, 65, 16);

        tabjoindatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabletpanel.add(tabjoindatet);
        tabjoindatet.setBounds(140, 110, 90, 20);

        tablastupdatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tablastupdatel.setText("LAST UPDATE");
        tabletpanel.add(tablastupdatel);
        tablastupdatel.setBounds(250, 110, 77, 16);

        tabaddtabletsl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabaddtabletsl.setText("ADD TABLETS");
        tabletpanel.add(tabaddtabletsl);
        tabaddtabletsl.setBounds(440, 70, 78, 16);

        tabaddtabletsc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TABLET", "SLIP"}));
        tabaddtabletsc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                tabaddtabletscItemStateChanged(evt);
            }
        });
        tabaddtabletsc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tabaddtabletscActionPerformed(evt);
            }
        });
        tabletpanel.add(tabaddtabletsc);
        tabaddtabletsc.setBounds(530, 70, 72, 22);

        tabactualtabletsl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabactualtabletsl.setText("ACTUAL TABLETS COUNT");
        tabletpanel.add(tabactualtabletsl);
        tabactualtabletsl.setBounds(440, 120, 141, 16);

        tabactualtabletst.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabletpanel.add(tabactualtabletst);
        tabactualtabletst.setBounds(597, 120, 60, 20);

        tabexistingtabletsl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabexistingtabletsl.setText("EXISTING TABLETS");
        tabletpanel.add(tabexistingtabletsl);
        tabexistingtabletsl.setBounds(260, 160, 100, 16);

        tabexistingtabletst.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabletpanel.add(tabexistingtabletst);
        tabexistingtabletst.setBounds(380, 160, 80, 20);

        tabexpireydatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabexpireydatel.setText("EXPIREY DATE");
        tabletpanel.add(tabexpireydatel);
        tabexpireydatel.setBounds(30, 140, 80, 30);

        tabexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        tabexpireydatet.setDateFormatString("yyyy-MM-dd");
        tabletpanel.add(tabexpireydatet);
        tabexpireydatet.setBounds(120, 170, 103, 20);

        tabslipquantityt.setBackground(new java.awt.Color(120, 185, 170));
        tabslipquantityt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabslipquantityt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tabslipquantityt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tabslipquantitytKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tabslipquantitytKeyTyped(evt);
            }
        });
        tabletpanel.add(tabslipquantityt);
        tabslipquantityt.setBounds(140, 70, 64, 21);

        tabslipratet.setEditable(false);
        tabslipratet.setBackground(new java.awt.Color(120, 185, 170));
        tabslipratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabslipratet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tabslipratet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tabslipratetKeyTyped(evt);
            }
        });
        tabletpanel.add(tabslipratet);
        tabslipratet.setBounds(350, 70, 64, 21);

        tabonceratet.setBackground(new java.awt.Color(120, 185, 170));
        tabonceratet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabonceratet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tabonceratet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tabonceratetKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tabonceratetKeyTyped(evt);
            }
        });
        tabletpanel.add(tabonceratet);
        tabonceratet.setBounds(550, 30, 64, 21);

        tabaddtabletst.setBackground(new java.awt.Color(120, 185, 170));
        tabaddtabletst.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabaddtabletst.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tabaddtabletst.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tabaddtabletstKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tabaddtabletstKeyTyped(evt);
            }
        });
        tabletpanel.add(tabaddtabletst);
        tabaddtabletst.setBounds(610, 70, 64, 21);

        tablastupdatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tabletpanel.add(tablastupdatet);
        tablastupdatet.setBounds(350, 110, 80, 20);

        medservercategory.addTab("tab1", tabletpanel);

        liquidpanel.setBackground(new java.awt.Color(120, 185, 170));
        liquidpanel.setLayout(null);

        liqidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqidl.setText("LIQUID ID");
        liquidpanel.add(liqidl);
        liqidl.setBounds(43, 41, 57, 16);

        liqnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqnamel.setText("LIQUID NAME");
        liquidpanel.add(liqnamel);
        liqnamel.setBounds(200, 40, 80, 16);

        liqnamet.setBackground(new java.awt.Color(120, 185, 170));
        liqnamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        liqnamet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                liqnametActionPerformed(evt);
            }
        });
        liquidpanel.add(liqnamet);
        liqnamet.setBounds(290, 40, 64, 17);

        liqonceratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqonceratel.setText("ONCE RATE");
        liquidpanel.add(liqonceratel);
        liqonceratel.setBounds(30, 100, 70, 16);

        liqmll.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqmll.setText("ML");
        liquidpanel.add(liqmll);
        liqmll.setBounds(420, 40, 30, 20);

        liqexpireydatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqexpireydatel.setText("EXPIREY DATE");
        liquidpanel.add(liqexpireydatel);
        liqexpireydatel.setBounds(200, 100, 80, 16);

        liqexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        liqexpireydatet.setDateFormatString("yyyy-MM-dd");
        liquidpanel.add(liqexpireydatet);
        liqexpireydatet.setBounds(290, 100, 103, 22);

        liqjoindatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqjoindatel.setText("JOIN DATE");
        liquidpanel.add(liqjoindatel);
        liqjoindatel.setBounds(420, 100, 60, 16);

        liqaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqaddl.setText("ADD LIQUID");
        liquidpanel.add(liqaddl);
        liqaddl.setBounds(30, 160, 70, 16);

        liqlastupdatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqlastupdatel.setText("LAST UPDATE");
        liquidpanel.add(liqlastupdatel);
        liqlastupdatel.setBounds(200, 160, 80, 16);

        liqexistingliquidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        liqexistingliquidl.setText("EXISTING LIQUID");
        liquidpanel.add(liqexistingliquidl);
        liqexistingliquidl.setBounds(410, 160, 90, 16);

        liqonceratet.setBackground(new java.awt.Color(120, 185, 170));
        liqonceratet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        liqonceratet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                liqonceratetKeyTyped(evt);
            }
        });
        liquidpanel.add(liqonceratet);
        liqonceratet.setBounds(110, 100, 64, 17);

        liqaddt.setBackground(new java.awt.Color(120, 185, 170));
        liqaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        liqaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                liqaddtKeyTyped(evt);
            }
        });
        liquidpanel.add(liqaddt);
        liqaddt.setBounds(110, 150, 64, 17);

        liqmlt.setBackground(new java.awt.Color(120, 185, 170));
        liqmlt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        liqmlt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                liqmltKeyTyped(evt);
            }
        });
        liquidpanel.add(liqmlt);
        liqmlt.setBounds(490, 50, 64, 17);

        liqjoindatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        liquidpanel.add(liqjoindatet);
        liqjoindatet.setBounds(510, 96, 90, 20);

        liqlastupdatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        liquidpanel.add(liqlastupdatet);
        liqlastupdatet.setBounds(297, 156, 90, 20);

        liqexistingliquidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        liquidpanel.add(liqexistingliquidt);
        liqexistingliquidt.setBounds(550, 160, 70, 20);

        liqidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        liquidpanel.add(liqidt);
        liqidt.setBounds(120, 40, 60, 20);

        medservercategory.addTab("tab2", liquidpanel);

        inhalerspanel.setBackground(new java.awt.Color(120, 185, 170));
        inhalerspanel.setLayout(null);

        inhidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhidl.setText("INHALER'S ID");
        inhalerspanel.add(inhidl);
        inhidl.setBounds(6, 14, 77, 16);

        inhnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhnamel.setText("INHALER NAME");
        inhalerspanel.add(inhnamel);
        inhnamel.setBounds(205, 14, 87, 16);

        inhnamet.setBackground(new java.awt.Color(120, 185, 170));
        inhnamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inhalerspanel.add(inhnamet);
        inhnamet.setBounds(316, 11, 64, 17);

        inhmgl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhmgl.setText("MG");
        inhalerspanel.add(inhmgl);
        inhmgl.setBounds(427, 14, 32, 16);

        inhmgt.setBackground(new java.awt.Color(120, 185, 170));
        inhmgt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inhmgt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inhmgtActionPerformed(evt);
            }
        });
        inhmgt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inhmgtKeyTyped(evt);
            }
        });
        inhalerspanel.add(inhmgt);
        inhmgt.setBounds(486, 11, 64, 17);

        inhonceratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhonceratel.setText("ONCE RATE");
        inhalerspanel.add(inhonceratel);
        inhonceratel.setBounds(10, 50, 63, 16);

        inhonceratet.setBackground(new java.awt.Color(120, 185, 170));
        inhonceratet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inhonceratet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inhonceratetKeyTyped(evt);
            }
        });
        inhalerspanel.add(inhonceratet);
        inhonceratet.setBounds(100, 50, 64, 17);

        inhexpireydatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhexpireydatel.setText("EXPIREY DATE");
        inhalerspanel.add(inhexpireydatel);
        inhexpireydatel.setBounds(200, 50, 79, 16);

        inhexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        inhexpireydatet.setDateFormatString("yyyy-MM-dd");
        inhalerspanel.add(inhexpireydatet);
        inhexpireydatet.setBounds(300, 50, 110, 22);

        inhjoindatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhjoindatel.setText("JOIN DATE");
        inhalerspanel.add(inhjoindatel);
        inhjoindatel.setBounds(440, 50, 60, 16);

        inhlastupdatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhlastupdatel.setText("LASTUPDATE");
        inhalerspanel.add(inhlastupdatel);
        inhlastupdatel.setBounds(430, 100, 80, 16);

        inhexistingl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhexistingl.setText("EXISTING INHALERS");
        inhalerspanel.add(inhexistingl);
        inhexistingl.setBounds(200, 100, 110, 20);

        inhaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inhaddl.setText("ADD INHALERS");
        inhalerspanel.add(inhaddl);
        inhaddl.setBounds(10, 100, 90, 20);

        inhaddt.setBackground(new java.awt.Color(120, 185, 170));
        inhaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inhaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inhaddtKeyTyped(evt);
            }
        });
        inhalerspanel.add(inhaddt);
        inhaddt.setBounds(100, 100, 64, 17);

        inhidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        inhalerspanel.add(inhidt);
        inhidt.setBounds(110, 10, 50, 20);

        inhjoindatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        inhalerspanel.add(inhjoindatet);
        inhjoindatet.setBounds(530, 50, 90, 20);

        inhlastupdatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        inhalerspanel.add(inhlastupdatet);
        inhlastupdatet.setBounds(550, 100, 80, 20);

        inhexistingt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        inhalerspanel.add(inhexistingt);
        inhexistingt.setBounds(330, 100, 70, 20);

        medservercategory.addTab("tab3", inhalerspanel);

        otherpanel.setBackground(new java.awt.Color(120, 185, 170));
        otherpanel.setLayout(null);

        itmidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmidl.setText("ITEM ID");
        otherpanel.add(itmidl);
        itmidl.setBounds(20, 17, 44, 16);

        itmidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        otherpanel.add(itmidt);
        itmidt.setBounds(117, 20, 60, 20);

        itmnamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmnamel.setText("ITEM NAME");
        otherpanel.add(itmnamel);
        itmnamel.setBounds(210, 20, 70, 16);

        itmnamet.setBackground(new java.awt.Color(120, 185, 170));
        itmnamet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        otherpanel.add(itmnamet);
        itmnamet.setBounds(300, 20, 64, 17);

        itmonceratel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmonceratel.setText("ONCE RATE");
        otherpanel.add(itmonceratel);
        itmonceratel.setBounds(430, 20, 70, 20);

        itmonceratet.setBackground(new java.awt.Color(120, 185, 170));
        itmonceratet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        itmonceratet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmonceratetActionPerformed(evt);
            }
        });
        itmonceratet.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itmonceratetKeyTyped(evt);
            }
        });
        otherpanel.add(itmonceratet);
        itmonceratet.setBounds(550, 20, 64, 17);

        itmjoindatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmjoindatel.setText("JOIN DATE");
        otherpanel.add(itmjoindatel);
        itmjoindatel.setBounds(220, 80, 70, 16);

        itmjoindatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        otherpanel.add(itmjoindatet);
        itmjoindatet.setBounds(310, 80, 70, 20);

        itmlastupdatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmlastupdatel.setText("LASTUPATE");
        otherpanel.add(itmlastupdatel);
        itmlastupdatel.setBounds(440, 80, 70, 16);

        itmlastupdatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        otherpanel.add(itmlastupdatet);
        itmlastupdatet.setBounds(550, 80, 90, 20);

        itmexpireydatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmexpireydatel.setText("EXPIREY DATE");
        otherpanel.add(itmexpireydatel);
        itmexpireydatel.setBounds(0, 70, 80, 30);

        itmexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        itmexpireydatet.setDateFormatString("yyyy-MM-dd");
        otherpanel.add(itmexpireydatet);
        itmexpireydatet.setBounds(100, 72, 100, 20);

        itmaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmaddl.setText("ADD ITEM");
        otherpanel.add(itmaddl);
        itmaddl.setBounds(10, 140, 60, 16);

        itmaddt.setBackground(new java.awt.Color(120, 185, 170));
        itmaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        itmaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itmaddtKeyTyped(evt);
            }
        });
        otherpanel.add(itmaddt);
        itmaddt.setBounds(90, 130, 64, 17);

        itmexistingl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itmexistingl.setText("EXISTING ITEM");
        otherpanel.add(itmexistingl);
        itmexistingl.setBounds(210, 130, 80, 20);

        itmexistingt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        otherpanel.add(itmexistingt);
        itmexistingt.setBounds(330, 130, 70, 20);

        medservercategory.addTab("tab4", otherpanel);

        medpagepanel.add(medservercategory);
        medservercategory.setBounds(190, 240, 730, 210);

        medtabicon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        medtabicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tabicon.png"))); // NOI18N
        medtabicon.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        medpagepanel.add(medtabicon);
        medtabicon.setBounds(20, 290, 140, 110);

        medinhicon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        medinhicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inhicon.png"))); // NOI18N
        medinhicon.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        medpagepanel.add(medinhicon);
        medinhicon.setBounds(20, 260, 150, 150);

        meditmicon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        meditmicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/itemicon.png"))); // NOI18N
        meditmicon.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        medpagepanel.add(meditmicon);
        meditmicon.setBounds(10, 270, 170, 140);

        medliqicon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        medliqicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/liqicon.png"))); // NOI18N
        medliqicon.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        medpagepanel.add(medliqicon);
        medliqicon.setBounds(30, 270, 140, 140);

        servercategory.addTab("tab2", medpagepanel);

        meddetailspage.setBackground(new java.awt.Color(120, 185, 170));
        meddetailspage.setLayout(null);

        meddetailmodel1=new DefaultTableModel();
        meddetailtable.setBackground(new java.awt.Color(255, 102, 102));
        meddetailtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        meddetailtable.setForeground(new java.awt.Color(255, 255, 255));
        meddetailtable.setModel(meddetailmodel1);
        jScrollPane2.setViewportView(meddetailtable);

        meddetailspage.add(jScrollPane2);
        jScrollPane2.setBounds(20, 80, 830, 390);

        medgotomed.setBackground(new java.awt.Color(255, 102, 102));
        medgotomed.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        medgotomed.setForeground(new java.awt.Color(255, 255, 255));
        medgotomed.setText("GO TO MEDICINE PAGE");
        medgotomed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medgotomedActionPerformed(evt);
            }
        });
        meddetailspage.add(medgotomed);
        medgotomed.setBounds(653, 24, 159, 30);

        servercategory.addTab("tab3", meddetailspage);

        stockspage.setBackground(new java.awt.Color(120, 185, 170));

        stotodayb.setBackground(new java.awt.Color(128, 123, 123));
        stotodayb.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stotodayb.setForeground(new java.awt.Color(255, 255, 255));
        stotodayb.setText("TODAY DETAILS");
        stotodayb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stotodaybActionPerformed(evt);
            }
        });

        stosearchb.setBackground(new java.awt.Color(128, 123, 123));
        stosearchb.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stosearchb.setForeground(new java.awt.Color(255, 255, 255));
        stosearchb.setText("SEARCH DETAILS");
        stosearchb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stosearchbActionPerformed(evt);
            }
        });

        stopendingb.setBackground(new java.awt.Color(128, 123, 123));
        stopendingb.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopendingb.setForeground(new java.awt.Color(255, 255, 255));
        stopendingb.setText("PENDING STOCKS");
        stopendingb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopendingbActionPerformed(evt);
            }
        });

        stocategory.setTabPlacement(javax.swing.JTabbedPane.RIGHT);

        stotodaypanel.setBackground(new java.awt.Color(120, 185, 170));
        stotodaypanel.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TODAY'S SALSE DETAILS");
        stotodaypanel.add(jLabel1);
        jLabel1.setBounds(260, 20, 211, 25);

        stotodaymodel=new DefaultTableModel();
        stotodaytable.setBackground(new java.awt.Color(255, 102, 102));
        stotodaytable.setForeground(new java.awt.Color(255, 255, 255));
        stotodaytable.setModel(stotodaymodel);
        stotodaytable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stotodaytableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(stotodaytable);

        stotodaypanel.add(jScrollPane1);
        jScrollPane1.setBounds(20, 60, 690, 240);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CUSTOMER DETAILS");
        stotodaypanel.add(jLabel4);
        jLabel4.setBounds(120, 320, 114, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("CUSTOMER ID");
        stotodaypanel.add(jLabel6);
        jLabel6.setBounds(80, 366, 110, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("EMPLOYEE ID");
        stotodaypanel.add(jLabel7);
        jLabel7.setBounds(80, 400, 110, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("SALSE DATE");
        stotodaypanel.add(jLabel8);
        jLabel8.setBounds(80, 436, 100, 20);

        stotodayviewmodel=new DefaultTableModel();
        stotodayviewtable.setBackground(new java.awt.Color(255, 102, 102));
        stotodayviewtable.setModel(stotodayviewmodel);
        jScrollPane3.setViewportView(stotodayviewtable);

        stotodaypanel.add(jScrollPane3);
        jScrollPane3.setBounds(320, 340, 270, 130);

        stocustidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stocustidt.setText("NULL");
        stotodaypanel.add(stocustidt);
        stocustidt.setBounds(230, 370, 80, 20);

        stoempidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stoempidt.setText("NULL");
        stotodaypanel.add(stoempidt);
        stoempidt.setBounds(230, 400, 90, 20);

        stosalsedatet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stosalsedatet.setText("NULL");
        stotodaypanel.add(stosalsedatet);
        stosalsedatet.setBounds(230, 440, 90, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("CUSTOMER MAIL ID");
        stotodaypanel.add(jLabel12);
        jLabel12.setBounds(80, 470, 120, 20);

        stocustmailidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stocustmailidt.setText("NULL");
        stotodaypanel.add(stocustmailidt);
        stocustmailidt.setBounds(230, 470, 140, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("TOTAL AMOUNT");
        stotodaypanel.add(jLabel9);
        jLabel9.setBounds(470, 480, 100, 16);

        stotodaytott.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stotodaytott.setText("0 Rs");
        stotodaypanel.add(stotodaytott);
        stotodaytott.setBounds(590, 480, 70, 20);

        jButton1.setBackground(new java.awt.Color(128, 123, 123));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("TAKE DOC");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        stotodaypanel.add(jButton1);
        jButton1.setBounds(620, 330, 90, 30);

        stocategory.addTab("tab1", stotodaypanel);

        stosearchpanel.setBackground(new java.awt.Color(120, 185, 170));
        stosearchpanel.setLayout(null);

        stosearchmodel=new DefaultTableModel();
        stosearchtable.setBackground(new java.awt.Color(255, 102, 102));
        stosearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stosearchtable.setForeground(new java.awt.Color(255, 255, 255));
        stosearchtable.setModel(stosearchmodel);
        stosearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stosearchtableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(stosearchtable);

        stosearchpanel.add(jScrollPane4);
        jScrollPane4.setBounds(28, 121, 663, 220);

        stosearchtot.setBackground(new java.awt.Color(120, 185, 170));
        stosearchtot.setDateFormatString("yyyy-MM-dd");
        stosearchpanel.add(stosearchtot);
        stosearchtot.setBounds(463, 53, 116, 22);

        stosearchfromt.setBackground(new java.awt.Color(120, 185, 170));
        stosearchfromt.setDateFormatString("yyyy-MM-dd");
        stosearchpanel.add(stosearchfromt);
        stosearchfromt.setBounds(291, 53, 116, 22);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("FROM");
        stosearchpanel.add(jLabel11);
        jLabel11.setBounds(211, 53, 62, 22);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("TO");
        stosearchpanel.add(jLabel13);
        jLabel13.setBounds(415, 53, 40, 22);

        stosearch.setBackground(new java.awt.Color(128, 123, 123));
        stosearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stosearch.setForeground(new java.awt.Color(255, 255, 255));
        stosearch.setText("SEARCH");
        stosearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stosearchActionPerformed(evt);
            }
        });
        stosearchpanel.add(stosearch);
        stosearch.setBounds(617, 45, 90, 30);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("ENTER THE DATE TO SEARCH");
        stosearchpanel.add(jLabel14);
        jLabel14.setBounds(28, 53, 165, 22);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("TOTAL AMOUNT ");
        stosearchpanel.add(jLabel10);
        jLabel10.setBounds(520, 380, 96, 22);

        stosearchtott.setText("0 Rs");
        stosearchpanel.add(stosearchtott);
        stosearchtott.setBounds(640, 380, 53, 22);

        jButton2.setBackground(new java.awt.Color(128, 123, 123));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("TAKE DOC");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        stosearchpanel.add(jButton2);
        jButton2.setBounds(50, 410, 110, 30);

        stosearchviewmodel=new DefaultTableModel();
        stosearchviewtable.setBackground(new java.awt.Color(255, 102, 102));
        stosearchviewtable.setModel(stosearchviewmodel);
        jScrollPane8.setViewportView(stosearchviewtable);

        stosearchpanel.add(jScrollPane8);
        jScrollPane8.setBounds(170, 352, 330, 130);

        stocategory.addTab("tab2", stosearchpanel);

        stopendingpanel.setBackground(new java.awt.Color(120, 185, 170));
        stopendingpanel.setLayout(null);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("ENTER MEDICINE NAME TO SEARCH");
        stopendingpanel.add(jLabel15);
        jLabel15.setBounds(130, 20, 200, 30);

        stopensearcht.setBackground(new java.awt.Color(120, 185, 170));
        stopensearcht.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopensearcht.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        stopensearcht.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopensearchtActionPerformed(evt);
            }
        });
        stopensearcht.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                stopensearchtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                stopensearchtKeyTyped(evt);
            }
        });
        stopendingpanel.add(stopensearcht);
        stopensearcht.setBounds(340, 20, 130, 20);

        stopensearchmodel=new DefaultTableModel();
        stopensearchtable.setBackground(new java.awt.Color(255, 102, 102));
        stopensearchtable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopensearchtable.setForeground(new java.awt.Color(255, 255, 255));
        stopensearchtable.setModel(stopensearchmodel);
        stopensearchtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stopensearchtableMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(stopensearchtable);

        stopendingpanel.add(jScrollPane5);
        jScrollPane5.setBounds(10, 60, 710, 90);

        stopentablemodel=new DefaultTableModel();
        stopentable.setBackground(new java.awt.Color(255, 102, 102));
        stopentable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopentable.setForeground(new java.awt.Color(255, 255, 255));
        stopentable.setModel(stopentablemodel);
        stopentable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stopentableMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(stopentable);

        stopendingpanel.add(jScrollPane6);
        jScrollPane6.setBounds(10, 180, 710, 160);

        stopenupdate.setBackground(new java.awt.Color(128, 123, 123));
        stopenupdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenupdate.setForeground(new java.awt.Color(255, 255, 255));
        stopenupdate.setText("UPDATE");
        stopenupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopenupdateActionPerformed(evt);
            }
        });
        stopendingpanel.add(stopenupdate);
        stopenupdate.setBounds(640, 410, 80, 40);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("PENDING STOCKS");
        stopendingpanel.add(jLabel16);
        jLabel16.setBounds(20, 160, 140, 16);

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("ADD MEDICINE");
        stopendingpanel.add(jLabel17);
        jLabel17.setBounds(20, 350, 110, 16);

        stopencategory.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        stopentabpanel.setBackground(new java.awt.Color(120, 185, 170));
        stopentabpanel.setLayout(null);

        stopentabexistingl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopentabexistingl.setText("EXISTING TABLETS");
        stopentabpanel.add(stopentabexistingl);
        stopentabexistingl.setBounds(26, 12, 106, 16);

        stopentabexistingt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopentabpanel.add(stopentabexistingt);
        stopentabexistingt.setBounds(140, 10, 60, 20);

        stopentabaddc.setBackground(new java.awt.Color(255, 102, 102));
        stopentabaddc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TABLET", "SLIP" }));
        stopentabaddc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                stopentabaddcItemStateChanged(evt);
            }
        });
        stopentabaddc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopentabaddcActionPerformed(evt);
            }
        });
        stopentabpanel.add(stopentabaddc);
        stopentabaddc.setBounds(330, 10, 72, 22);

        stopentabaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopentabaddl.setText("ADD NEW TABLETS");
        stopentabpanel.add(stopentabaddl);
        stopentabaddl.setBounds(210, 10, 110, 16);

        stopentabaddt.setBackground(new java.awt.Color(120, 185, 170));
        stopentabaddt.setAutoscrolls(false);
        stopentabaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        stopentabaddt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopentabaddtActionPerformed(evt);
            }
        });
        stopentabaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                stopentabaddtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                stopentabaddtKeyTyped(evt);
            }
        });
        stopentabpanel.add(stopentabaddt);
        stopentabaddt.setBounds(410, 10, 52, 17);
        stopentabaddt.getAccessibleContext().setAccessibleName("");

        stopentabactuall.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopentabactuall.setText("ACTUAL TAB");
        stopentabpanel.add(stopentabactuall);
        stopentabactuall.setBounds(480, 10, 72, 16);

        stopentabactualt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopentabpanel.add(stopentabactualt);
        stopentabactualt.setBounds(570, 10, 60, 20);

        stopentabexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        stopentabexpireydatet.setDateFormatString("yyyy-MM-dd");
        stopentabpanel.add(stopentabexpireydatet);
        stopentabexpireydatet.setBounds(136, 46, 119, 22);

        stopentabexpireyl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopentabexpireyl.setText("EXPIREY DATE");
        stopentabpanel.add(stopentabexpireyl);
        stopentabexpireyl.setBounds(28, 46, 96, 22);

        stopencategory.addTab("tab1", stopentabpanel);

        stopenotherpanel.setBackground(new java.awt.Color(120, 185, 170));
        stopenotherpanel.setLayout(null);

        stopenothexistingl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenothexistingl.setText("EXISTING MEDICINE");
        stopenotherpanel.add(stopenothexistingl);
        stopenothexistingl.setBounds(30, 20, 120, 16);
        stopenotherpanel.add(stopenothexistingt);
        stopenothexistingt.setBounds(150, 20, 50, 20);

        stopenothaddl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenothaddl.setText("ADD NEW MEDICINE");
        stopenotherpanel.add(stopenothaddl);
        stopenothaddl.setBounds(220, 20, 115, 16);

        stopenothaddt.setBackground(new java.awt.Color(120, 185, 170));
        stopenothaddt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        stopenothaddt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopenothaddtActionPerformed(evt);
            }
        });
        stopenothaddt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                stopenothaddtKeyTyped(evt);
            }
        });
        stopenotherpanel.add(stopenothaddt);
        stopenothaddt.setBounds(350, 17, 64, 20);

        stopenothexpireydatel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenothexpireydatel.setText("EXPIREY DATE");
        stopenotherpanel.add(stopenothexpireydatel);
        stopenothexpireydatel.setBounds(440, 20, 79, 16);

        stopenothexpireydatet.setBackground(new java.awt.Color(120, 185, 170));
        stopenothexpireydatet.setDateFormatString("yyyy-MM-dd");
        stopenotherpanel.add(stopenothexpireydatet);
        stopenothexpireydatet.setBounds(530, 20, 99, 22);

        stopencategory.addTab("tab2", stopenotherpanel);

        stopendingpanel.add(stopencategory);
        stopencategory.setBounds(-50, 410, 680, 80);

        stopenmedidl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenmedidl.setText("MEDICINE ID");
        stopendingpanel.add(stopenmedidl);
        stopenmedidl.setBounds(28, 390, 80, 16);

        stopenmedidt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopendingpanel.add(stopenmedidt);
        stopenmedidt.setBounds(120, 390, 70, 20);

        stopenmednamel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopenmednamel.setText("MEDICINE NAME");
        stopendingpanel.add(stopenmednamel);
        stopenmednamel.setBounds(200, 390, 93, 16);

        stopenmednamet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopendingpanel.add(stopenmednamet);
        stopenmednamet.setBounds(310, 390, 92, 20);

        stopencategoryl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        stopencategoryl.setText("MEDICINE CATEGORY");
        stopendingpanel.add(stopencategoryl);
        stopencategoryl.setBounds(410, 390, 120, 16);

        stopenmedcategoryt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        stopendingpanel.add(stopenmedcategoryt);
        stopenmedcategoryt.setBounds(540, 390, 62, 20);

        stocategory.addTab("tab3", stopendingpanel);

        javax.swing.GroupLayout stockspageLayout = new javax.swing.GroupLayout(stockspage);
        stockspage.setLayout(stockspageLayout);
        stockspageLayout.setHorizontalGroup(
            stockspageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockspageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(stockspageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(stockspageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(stosearchb, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(stotodayb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(stopendingb, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(stocategory, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        stockspageLayout.setVerticalGroup(
            stockspageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockspageLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(stotodayb, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(110, 110, 110)
                .addComponent(stosearchb, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(stopendingb, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, stockspageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(stocategory, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                .addContainerGap())
        );

        servercategory.addTab("tab4", stockspage);

        getContentPane().add(servercategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 55, 870, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void medicinedetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medicinedetailsActionPerformed
        // TODO add your handling code here:
        servercategory.setSelectedIndex(2);
        meddefault();
    }//GEN-LAST:event_medicinedetailsActionPerformed

    private void employeedetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeedetailsActionPerformed
        // TODO add your handling code here:
        servercategory.setSelectedIndex(0);
    }//GEN-LAST:event_employeedetailsActionPerformed

    private void empusernametActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empusernametActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_empusernametActionPerformed

    private void emppasswordtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emppasswordtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emppasswordtActionPerformed

    private void empcancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empcancelActionPerformed
        empdefault();
    }//GEN-LAST:event_empcancelActionPerformed

    private void empaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empaddActionPerformed
        if(empusernamet.getText().equals("")||emppasswordt.getText().equals("")||empphonet.getText().equals("")||empusernamet.getText().contains(" ")||emppasswordt.getText().contains(" ")||empphonet.getText().contains(" "))
                JOptionPane.showMessageDialog(this,"its wrong..");
            else{
                try{
                    int o=0;
                    ResultSet rs=stmt.executeQuery("select * from employee");
                    while(rs.next()){               
                        if(rs.getString(2).equals(empusernamet.getText()) && rs.getString(3).equals(emppasswordt.getText())){
                            o++;
                            break;
                        }
                    }
                    if(o>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't create acc..");
                        empdefault();  
                    }
                    else{
                        stmt.executeUpdate("insert into employee values('"+empidt.getText()+"','"+empusernamet.getText()+"','"+emppasswordt.getText()+"','"+empphonet.getText()+"','"+empmailt.getText()+"','"+empjoindatet.getText()+"','"+emplastupdatet.getText()+"')");
                        empdefault();
                        empdisplay();
                    }
                }
                catch(Exception j){
                    System.out.println(j);
                }
            }
    }//GEN-LAST:event_empaddActionPerformed

    private void stockdetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockdetailsActionPerformed
        servercategory.setSelectedIndex(4);
        try{
            stocategory.setSelectedIndex(0);
            stotodaymodel.setRowCount(0);
            ResultSet ry=stmt.executeQuery("select * from salseitem where purchasedate='"+java.time.LocalDate.now().toString()+"'");
            while(ry.next())
                stotodaymodel.addRow(new Object[]{ry.getString(1),ry.getString(2),ry.getString(3),ry.getString(4),ry.getString(5),ry.getString(6),ry.getString(7)});           
            if(stotodaymodel.getRowCount()<=0);
            else{
            stocustidt.setText(stotodaymodel.getValueAt(0,0).toString());
            stoempidt.setText(stotodaymodel.getValueAt(0,1).toString());
            stocustmailidt.setText(stotodaymodel.getValueAt(0,4).toString());
            stosalsedatet.setText(stotodaymodel.getValueAt(0,6).toString());
            String sto=stotodaymodel.getValueAt(0,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            stotodayviewmodel.setRowCount(0);
            for(int i=0;i<stoarray.length;i++){
                stotodayviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});              
                i+=2;
            }
            stotodaytott.setText(stotodaymodel.getValueAt(0,3).toString());
        }
        }
        catch(Exception z){
            System.out.println(z);
        }
    }//GEN-LAST:event_stockdetailsActionPerformed

    private void employeelistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeelistActionPerformed
         servercategory.setSelectedIndex(1);
         empdisplay();
    }//GEN-LAST:event_employeelistActionPerformed

    private void medicinelistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medicinelistActionPerformed
        servercategory.setSelectedIndex(3);
        meddisplay();
    }//GEN-LAST:event_medicinelistActionPerformed

    private void medsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medsaveActionPerformed
           if(medaddc.getSelectedItem()=="TABLETS"){
            try{
                if(tabnamet.getText().equals(taboldname)){
                    if(tabactualtabletst.getText().equals("")||tabactualtabletst.getText().contains(" ")){
                        stmt.executeUpdate("update medicine set medname='"+tabnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(tabonceratet.getText())+",slipquantity="+Integer.valueOf(tabslipquantityt.getText())+",sliprate="+Integer.valueOf(tabslipratet.getText())+",expireydate='"+dcn.format(tabexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+tabidt.getText()+"'");
                        meddefault();
                    }
                    else{
                        stmt.executeUpdate("update medicine set medname='"+tabnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(tabonceratet.getText())+",slipquantity="+Integer.valueOf(tabslipquantityt.getText())+",sliprate="+Integer.valueOf(tabslipratet.getText())+",expireydate='"+dcn.format(tabexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(tabactualtabletst.getText())+Integer.valueOf(tabexistingtabletst.getText()))+" where medid='"+tabidt.getText()+"'");
                        meddefault();
                    }
                }
                else {
                    int n=0;
                    ResultSet sr=stmt.executeQuery("select medname from medicine");
                    while(sr.next()){
                        if(tabnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                    }
                    if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");
                        meddefault();
                    }
                    else{
                        if(tabactualtabletst.getText().equals("")||tabactualtabletst.getText().contains(" ")){
                            stmt.executeUpdate("update medicine set medname='"+tabnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(tabonceratet.getText())+",slipquantity="+Integer.valueOf(tabslipquantityt.getText())+",sliprate="+Integer.valueOf(tabslipratet.getText())+",expireydate='"+dcn.format(tabexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+tabidt.getText()+"'");
                            meddefault();
                        }
                        else{
                            stmt.executeUpdate("update medicine set medname='"+tabnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(tabonceratet.getText())+",slipquantity="+Integer.valueOf(tabslipquantityt.getText())+",sliprate="+Integer.valueOf(tabslipratet.getText())+",expireydate='"+dcn.format(tabexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(tabactualtabletst.getText())+Integer.valueOf(tabexistingtabletst.getText()))+" where medid='"+tabidt.getText()+"'");
                            meddefault();
                        }        
                    }
                }
            }
            catch(SQLException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            catch(java.lang.NumberFormatException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            
        }
        else if(medaddc.getSelectedItem()=="LIQUID"){
            try{
                if(liqnamet.getText().equals(liqoldname)){
                    if(liqaddt.getText().equals("")||liqaddt.getText().contains(" ")){
                        stmt.executeUpdate("update medicine set medname='"+liqnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(liqonceratet.getText())+",ml="+Integer.valueOf(liqmlt.getText())+",expireydate='"+dcn.format(liqexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+liqidt.getText()+"'");
                        liquidalignment1();
                    }
                    else{
                        stmt.executeUpdate("update medicine set medname='"+liqnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(liqonceratet.getText())+",ml="+Integer.valueOf(liqmlt.getText())+",expireydate='"+dcn.format(liqexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(liqexistingliquidt.getText())+Integer.valueOf(liqaddt.getText()))+" where medid='"+liqidt.getText()+"'");
                        liquidalignment1();
                    }
                }
                else {
                    int n=0;
                    ResultSet sr=stmt.executeQuery("select medname from medicine");
                    while(sr.next()){
                        if(liqnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                    }
                    if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");
                        liquidalignment1();
                    }
                    else{
                        if(liqaddt.getText().equals("")||liqaddt.getText().contains(" ")){
                            stmt.executeUpdate("update medicine set medname='"+liqnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(liqonceratet.getText())+",ml="+Integer.valueOf(liqmlt.getText())+",expireydate='"+dcn.format(liqexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+liqidt.getText()+"'");
                            liquidalignment1();
                        }
                        else{
                            stmt.executeUpdate("update medicine set medname='"+liqnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(liqonceratet.getText())+",ml="+Integer.valueOf(liqmlt.getText())+",expireydate='"+dcn.format(liqexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(liqexistingliquidt.getText())+Integer.valueOf(liqaddt.getText()))+" where medid='"+liqidt.getText()+"'");
                            liquidalignment1();
                        }        
                    }
                }
            }
            catch(SQLException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            catch(java.lang.NumberFormatException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
        }
        else if(medaddc.getSelectedItem()=="INHALERS"){
            try{
                if(inhnamet.getText().equals(inholdname)){
                    if(inhaddt.getText().equals("")||inhaddt.getText().contains(" ")){
                        stmt.executeUpdate("update medicine set medname='"+inhnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(inhonceratet.getText())+",mg="+Integer.valueOf(inhmgt.getText())+",expireydate='"+dcn.format(inhexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+inhidt.getText()+"'");
                        inhaleralignment1();
                    }
                    else{
                        stmt.executeUpdate("update medicine set medname='"+inhnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(inhonceratet.getText())+",mg="+Integer.valueOf(inhmgt.getText())+",expireydate='"+dcn.format(inhexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(inhexistingt.getText())+Integer.valueOf(inhaddt.getText()))+" where medid='"+inhidt.getText()+"'");
                        inhaleralignment1();
                    }
                }
                else {
                    int n=0;
                    ResultSet sr=stmt.executeQuery("select medname from medicine");
                    while(sr.next()){
                        if(inhnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                    }
                    if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");
                        inhaleralignment1();
                    }
                    else{
                        if(inhaddt.getText().equals("")||inhaddt.getText().contains(" ")){
                            stmt.executeUpdate("update medicine set medname='"+inhnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(inhonceratet.getText())+",mg="+Integer.valueOf(inhmgt.getText())+",expireydate='"+dcn.format(inhexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+inhidt.getText()+"'");
                            inhaleralignment1();
                        }
                        else{
                            stmt.executeUpdate("update medicine set medname='"+inhnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(inhonceratet.getText())+",mg="+Integer.valueOf(inhmgt.getText())+",expireydate='"+dcn.format(inhexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(inhexistingt.getText())+Integer.valueOf(inhaddt.getText()))+" where medid='"+inhidt.getText()+"'");
                            inhaleralignment1();
                        }

                    }
                }
            }
            catch(SQLException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            catch(java.lang.NumberFormatException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
        }
        else if(medaddc.getSelectedItem()=="OTHERS"){
            try{
                if(itmnamet.getText().equals(itmoldname)){
                    if(itmaddt.getText().equals("")||itmaddt.getText().contains(" ")){
                        stmt.executeUpdate("update medicine set medname='"+itmnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(itmonceratet.getText())+",expireydate='"+dcn.format(itmexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+itmidt.getText()+"'");
                        otheralignment1();
                    }
                    else{
                        stmt.executeUpdate("update medicine set medname='"+itmnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(itmonceratet.getText())+",expireydate='"+dcn.format(itmexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(itmexistingt.getText())+Integer.valueOf(itmaddt.getText()))+" where medid='"+itmidt.getText()+"'");
                        otheralignment1();
                    }
                }
                else {
                    int n=0;
                    ResultSet sr=stmt.executeQuery("select medname from medicine");
                    while(sr.next()){
                        if(itmnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                    }
                    if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");
                        otheralignment1();
                    }
                    else{
                        if(itmaddt.getText().equals("")||itmaddt.getText().contains(" ")){
                            stmt.executeUpdate("update medicine set medname='"+itmnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(itmonceratet.getText())+",expireydate='"+dcn.format(itmexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+itmidt.getText()+"'");
                            otheralignment1();
                        }
                        else{
                            stmt.executeUpdate("update medicine set medname='"+itmnamet.getText()+"',category='"+medaddc.getSelectedItem()+"',oncerate="+Integer.valueOf(itmonceratet.getText())+",expireydate='"+dcn.format(itmexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"',numofmedicines="+(Integer.valueOf(itmexistingt.getText())+Integer.valueOf(itmaddt.getText()))+" where medid='"+itmidt.getText()+"'");
                            otheralignment1();
                        }

                    }
                }
            }
            catch(SQLException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            catch(java.lang.NumberFormatException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
        }
    }//GEN-LAST:event_medsaveActionPerformed

    private void meddeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meddeleteActionPerformed
        if(medaddc.getSelectedItem()=="TABLETS"){
            try{
            stmt.executeUpdate("delete from medicine where medid='"+tabidt.getText()+"'");
            tabletalignment1();
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
        else if(medaddc.getSelectedItem()=="LIQUID"){
            try{
            stmt.executeUpdate("delete from medicine where medid='"+liqidt.getText()+"'");
            liquidalignment1();
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
        else if(medaddc.getSelectedItem()=="INHALERS"){
            try{
            stmt.executeUpdate("delete from medicine where medid='"+inhidt.getText()+"'");
            inhaleralignment1();
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
        else if(medaddc.getSelectedItem()=="OTHERS"){
            try{
            stmt.executeUpdate("delete from medicine where medid='"+itmidt.getText()+"'");
            otheralignment1();
            }
            catch(Exception j){
                System.out.println(j);
            }
        }
    }//GEN-LAST:event_meddeleteActionPerformed

    private void medaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medaddActionPerformed
        try{
        if(medaddc.getSelectedItem()=="TABLETS"){
        if(tabnamet.getText().equals("")||tabonceratet.getText().equals("")||tabslipquantityt.getText().equals("")||dcn.format(tabexpireydatet.getDate()).equals("")||tabslipratet.getText().equals("")||tabaddtabletst.getText().equals("")||tabnamet.getText().contains(" ")||tabonceratet.getText().contains(" ")||tabslipquantityt.getText().contains(" ")||tabslipratet.getText().contains(" ")||dcn.format(tabexpireydatet.getDate()).contains(" ")||tabaddtabletst.getText().contains(" "))    
                JOptionPane.showMessageDialog(this,"Invalid Inputs");
        if(Integer.valueOf(tabaddtabletst.getText())<0)
            JOptionPane.showMessageDialog(this,"can't be minus value");
        else{                  
                   int n=0;
                   ResultSet sr=stmt.executeQuery("select medname from medicine");
                   while(sr.next()){
                        if(tabnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                   }
                   if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");                 
                   }
                   else{
                        stmt.executeUpdate("insert into medicine values('"+tabidt.getText()+"','"+tabnamet.getText()+"','"+medaddc.getSelectedItem()+"',"+Integer.valueOf(tabonceratet.getText())+","+Integer.valueOf(tabslipquantityt.getText())+","+Integer.valueOf(tabslipratet.getText())+","+0+","+0+","+Integer.valueOf(tabactualtabletst.getText())+",'"+dcn.format(tabexpireydatet.getDate())+"','"+tabjoindatet.getText()+"','"+null+"')");
                   }                
            }
        tabletalignment1();
        }
        else if(medaddc.getSelectedItem()=="LIQUID"){
            if(liqnamet.getText().equals("")||liqonceratet.getText().equals("")||liqmlt.getText().equals("")||dcn.format(liqexpireydatet.getDate()).equals("")||liqaddt.getText().equals("")||liqnamet.getText().contains(" ")||liqonceratet.getText().contains(" ")||liqmlt.getText().contains(" ")||dcn.format(liqexpireydatet.getDate()).contains(" ")||liqaddt.getText().contains(" "))    
                JOptionPane.showMessageDialog(this,"Invalid Inputs");
            if(Integer.valueOf(liqaddt.getText())<0)
            JOptionPane.showMessageDialog(this,"can't be minus value");
            else{             
                   int n=0;
                   ResultSet sr=stmt.executeQuery("select medname from medicine");
                   while(sr.next()){
                        if(liqnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                   }
                   if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");                       
                   }
                   else{
                       stmt.executeUpdate("insert into medicine values('"+liqidt.getText()+"','"+liqnamet.getText()+"','"+medaddc.getSelectedItem()+"',"+Integer.valueOf(liqonceratet.getText())+","+0+","+0+","+Integer.valueOf(liqmlt.getText())+","+0+","+Integer.valueOf(liqaddt.getText())+",'"+dcn.format(liqexpireydatet.getDate())+"','"+liqjoindatet.getText()+"','"+null+"')");
                   }              
            }
            liquidalignment1();
        }
        else if(medaddc.getSelectedItem()=="INHALERS"){
            if(inhnamet.getText().equals("")||inhonceratet.getText().equals("")||inhmgt.getText().equals("")||dcn.format(inhexpireydatet.getDate()).equals("")||inhaddt.getText().equals("")||inhnamet.getText().contains(" ")||inhonceratet.getText().contains(" ")||inhmgt.getText().contains(" ")||dcn.format(inhexpireydatet.getDate()).contains(" ")||inhaddt.getText().contains(" "))    
                JOptionPane.showMessageDialog(this,"Invalid Inputs");
            if(Integer.valueOf(inhaddt.getText())<0)
            JOptionPane.showMessageDialog(this,"can't be minus value");
            else{                 
                   int n=0;
                   ResultSet sr=stmt.executeQuery("select medname from medicine");
                   while(sr.next()){
                        if(inhnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                   }
                   if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");                       
                   }
                   else{
                       stmt.executeUpdate("insert into medicine values('"+inhidt.getText()+"','"+inhnamet.getText()+"','"+medaddc.getSelectedItem()+"',"+Integer.valueOf(inhonceratet.getText())+","+0+","+0+","+0+","+Integer.valueOf(inhmgt.getText())+","+Integer.valueOf(inhaddt.getText())+",'"+dcn.format(inhexpireydatet.getDate())+"','"+inhjoindatet.getText()+"','"+null+"')");
                   }              
            }
            inhaleralignment1();
        }
        else if(medaddc.getSelectedItem()=="OTHERS"){
            if(itmnamet.getText().equals("")||itmonceratet.getText().equals("")||dcn.format(itmexpireydatet.getDate()).equals("")||itmaddt.getText().equals("")||itmnamet.getText().contains(" ")||itmonceratet.getText().contains(" ")||dcn.format(itmexpireydatet.getDate()).contains(" ")||itmaddt.getText().contains(" "))    
                JOptionPane.showMessageDialog(this,"Invalid Inputs");
            if(Integer.valueOf(itmaddt.getText())<0)
            JOptionPane.showMessageDialog(this,"can't be minus value");
            else{                
                   int n=0;
                   ResultSet sr=stmt.executeQuery("select medname from medicine");
                   while(sr.next()){
                        if(itmnamet.getText().equals(sr.getString(1))){
                            n++;
                            break;
                        }
                   }
                   if(n>0){
                        JOptionPane.showMessageDialog(this,"its exists.. con't add newly..");                       
                   }
                   else{
                       stmt.executeUpdate("insert into medicine values('"+itmidt.getText()+"','"+itmnamet.getText()+"','"+medaddc.getSelectedItem()+"',"+Integer.valueOf(itmonceratet.getText())+","+0+","+0+","+0+","+0+","+Integer.valueOf(itmaddt.getText())+",'"+dcn.format(itmexpireydatet.getDate())+"','"+itmjoindatet.getText()+"','"+null+"')");
                   }              
            }
            otheralignment1();
        }
        }
        catch(SQLException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
            catch(java.lang.NumberFormatException j){
                JOptionPane.showMessageDialog(this,j);
                meddefault();
            }
    }//GEN-LAST:event_medaddActionPerformed

    private void medgotomedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medgotomedActionPerformed
        servercategory.setSelectedIndex(2);
        meddefault();
    }//GEN-LAST:event_medgotomedActionPerformed

    private void empsearchtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_empsearchtKeyReleased
        // TODO add your handling code here:
        if(empsearcht.getText().contains(" ")||empsearcht.getText().equals(""));
                else{
            try{
                    ResultSet rx=stmt.executeQuery("select * from employee where Eid like '"+empsearcht.getText()+"%' ");
                    while(rx.next())
                        empmodel1.addRow(new Object[]{rx.getString(1),rx.getString(2),rx.getString(3),rx.getString(4),rx.getString(5),rx.getString(6),rx.getString(7)});
        }
            catch(SQLException j){
                System.out.println(j);
            }
    }//GEN-LAST:event_empsearchtKeyReleased
    }
    private void empsearchtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_empsearchtKeyTyped
        // TODO add your handling code here:
        empmodel1.setRowCount(0);
    }//GEN-LAST:event_empsearchtKeyTyped

    private void empsearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_empsearchtableMouseClicked
        if(empmodel1.getRowCount()<=0);
        else{
            int selected;
            selected=empsearchtable.getSelectedRow();
            empidt.setText(empmodel1.getValueAt(selected,0).toString());
            empusernamet.setText(empmodel1.getValueAt(selected,1).toString());
            emppasswordt.setText(empmodel1.getValueAt(selected,2).toString());
            empphonet.setText(empmodel1.getValueAt(selected,3).toString());
            empmailt.setText(empmodel1.getValueAt(selected,4).toString());
            empjoindatet.setText(empmodel1.getValueAt(selected,5).toString());
            emplastupdatet.setText(empmodel1.getValueAt(selected,6).toString());
            emplastupdatel.setVisible(true);
            emplastupdatet.setVisible(true);
            empcancel.setVisible(true);
            empsave.setVisible(true);
            empdelete.setVisible(true);
            empadd.setVisible(false);
            empaddheadline.setText("UPDATE EMPLOYEE'S DETAILS");
            empsearcht.setText("");
            empmodel1.setRowCount(0);
        }
    }//GEN-LAST:event_empsearchtableMouseClicked

    private void empdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empdeleteActionPerformed
        try {
            stmt.executeUpdate("delete from employee where Eid='"+empidt.getText()+"'");
        } catch (SQLException j) {
            System.out.println(j);
        }
                empdefault();
                empdisplay();
    }//GEN-LAST:event_empdeleteActionPerformed

    private void empsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empsaveActionPerformed
        if(empusernamet.getText().equals("")||emppasswordt.getText().equals("")||empphonet.getText().equals("")||empusernamet.getText().contains(" ")||emppasswordt.getText().contains(" ")||empphonet.getText().contains(" ")){
                JOptionPane.showMessageDialog(this,"its wrong..");
                empdefault();
            }
            else{
                try{
                    stmt.executeUpdate("update employee set username='"+empusernamet.getText()+"',password='"+emppasswordt.getText()+"',phoneno='"+empphonet.getText()+"',mailid='"+empmailt.getText()+"',updatedate='"+java.time.LocalDate.now().toString()+"' where Eid='"+empidt.getText()+"'");
                    empdefault();
                }
                catch(SQLException j){
                    System.out.println(j);
                }
            }
        
        
    }//GEN-LAST:event_empsaveActionPerformed

    private void medsearchtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_medsearchtKeyReleased
     
           if(medsearcht.getText().equals("")||medsearcht.getText().contains(" "));
           else{
                try{
                    ResultSet rx=stmt.executeQuery("select * from medicine where medname like '"+medsearcht.getText()+"%' order by medid asc");
                    while(rx.next())
                            medmodel1.addRow(new Object[]{rx.getString(1),rx.getString(2),rx.getString(3),rx.getInt(4),rx.getInt(5),rx.getInt(6),rx.getInt(7),rx.getInt(8),rx.getInt(9),rx.getString(10),rx.getString(11),rx.getString(12)});
                }
                catch(SQLException j){
                    System.out.println(j);
                }
            }
       
       
    }//GEN-LAST:event_medsearchtKeyReleased

    private void medsearchtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_medsearchtKeyTyped
        medmodel1.setRowCount(0);
    }//GEN-LAST:event_medsearchtKeyTyped

    private void medsearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_medsearchtableMouseClicked
       if(medmodel1.getRowCount()<=0);
       else{
        try{
           int selected=medsearchtable.getSelectedRow();
           if(medmodel1.getValueAt(selected,2).toString().equals("TABLETS")){
                tabletalignment1();
                medaddc.setSelectedIndex(0);
                tabletalignment2();
                tabidt.setText(medmodel1.getValueAt(selected,0).toString());
                tabnamet.setText(medmodel1.getValueAt(selected,1).toString());
                taboldname=medmodel1.getValueAt(selected, 1).toString();
                tabonceratet.setText(medmodel1.getValueAt(selected,3).toString());
                tabslipquantityt.setText(medmodel1.getValueAt(selected,4).toString());
                tabslipratet.setText(medmodel1.getValueAt(selected,5).toString());
                tabexistingtabletst.setText(medmodel1.getValueAt(selected,8).toString());
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)medmodel1.getValueAt(selected, 9));
                    tabexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
                tabjoindatet.setText(medmodel1.getValueAt(selected,10).toString());
                tablastupdatet.setText(medmodel1.getValueAt(selected, 11).toString());
                tabaddtabletsl.setText("ADD EXTRA TABLETS");
                medmodel1.setRowCount(0); 
                medsearcht.setText("");
           }
           else if(medmodel1.getValueAt(selected,2).toString().equals("LIQUID")){
               liquidalignment1();
               medaddc.setSelectedIndex(1);
               liquidalignment2();
               liqidt.setText(medmodel1.getValueAt(selected,0).toString());
               liqnamet.setText(medmodel1.getValueAt(selected, 1).toString());
               liqoldname=medmodel1.getValueAt(selected,1).toString();
               liqonceratet.setText(medmodel1.getValueAt(selected,3).toString());
               liqmlt.setText(medmodel1.getValueAt(selected,6).toString());
               liqexistingliquidt.setText(medmodel1.getValueAt(selected,8).toString());
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)medmodel1.getValueAt(selected, 9));
                    liqexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
                liqjoindatet.setText(medmodel1.getValueAt(selected,10).toString());
                liqlastupdatet.setText(medmodel1.getValueAt(selected, 11).toString());
                medmodel1.setRowCount(0); 
                medsearcht.setText("");   
           }
           else if(medmodel1.getValueAt(selected,2).toString().equals("INHALERS")){
               inhaleralignment1();
               medaddc.setSelectedIndex(2);
               inhaleralignment2();
               inhidt.setText(medmodel1.getValueAt(selected,0).toString());
               inhnamet.setText(medmodel1.getValueAt(selected, 1).toString());
               inholdname=medmodel1.getValueAt(selected,1).toString();
               inhonceratet.setText(medmodel1.getValueAt(selected,3).toString());
               inhmgt.setText(medmodel1.getValueAt(selected,7).toString());
               inhexistingt.setText(medmodel1.getValueAt(selected,8).toString());
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)medmodel1.getValueAt(selected, 9));
                    inhexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
                inhjoindatet.setText(medmodel1.getValueAt(selected,10).toString());
                inhlastupdatet.setText(medmodel1.getValueAt(selected, 11).toString());
                medmodel1.setRowCount(0); 
                medsearcht.setText("");
           }
           else if(medmodel1.getValueAt(selected,2).toString().equals("OTHERS")){
               otheralignment1();
               medaddc.setSelectedIndex(3);
               otheralignment2();
               itmidt.setText(medmodel1.getValueAt(selected,0).toString());
               itmnamet.setText(medmodel1.getValueAt(selected, 1).toString());
               itmoldname=medmodel1.getValueAt(selected,1).toString();
               itmonceratet.setText(medmodel1.getValueAt(selected,3).toString());
               itmexistingt.setText(medmodel1.getValueAt(selected,8).toString());
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)medmodel1.getValueAt(selected, 9));
                    itmexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
                itmjoindatet.setText(medmodel1.getValueAt(selected,10).toString());
                itmlastupdatet.setText(medmodel1.getValueAt(selected, 11).toString());
                medmodel1.setRowCount(0); 
                medsearcht.setText("");
           }
       }
       catch(Exception j){
           System.out.println(j);
       }
     }
    }//GEN-LAST:event_medsearchtableMouseClicked

    private void tabaddtabletscItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_tabaddtabletscItemStateChanged
        if(tabaddtabletst.getText().equals("")||tabaddtabletst.getText().contains(" "));
            else{
                if(tabaddtabletsc.getSelectedItem()=="SLIP")
                    tabactualtabletst.setText(String.valueOf(Integer.valueOf(tabaddtabletst.getText())*Integer.valueOf(tabslipquantityt.getText())));
                else if(tabaddtabletsc.getSelectedItem()=="TABLET")
                    tabactualtabletst.setText(tabaddtabletst.getText());
            }
    }//GEN-LAST:event_tabaddtabletscItemStateChanged

    private void tabaddtabletstKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabaddtabletstKeyReleased
      if(tabaddtabletst.getText().equals("")||tabaddtabletst.getText().contains(" "))
               tabactualtabletst.setText("");
            else{
                if(tabaddtabletsc.getSelectedItem()=="TABLET")
                    tabactualtabletst.setText(tabaddtabletst.getText());
                else if(tabaddtabletsc.getSelectedItem()=="SLIP")
                    tabactualtabletst.setText(String.valueOf(Integer.valueOf(tabaddtabletst.getText())*Integer.valueOf(tabslipquantityt.getText())));
            }
    }//GEN-LAST:event_tabaddtabletstKeyReleased

    private void tabonceratetKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabonceratetKeyReleased
      
        if(tabonceratet.getText().equals("")||tabslipquantityt.getText().equals("")||tabonceratet.getText().contains(" ")||tabslipquantityt.getText().contains(" "))
                tabslipratet.setText("");
            else
            tabslipratet.setText(String.valueOf(Integer.valueOf(tabslipquantityt.getText())*Integer.valueOf(tabonceratet.getText())));
       //}
       //else{
           //evt.consume();
       //}
    }//GEN-LAST:event_tabonceratetKeyReleased

    private void tabslipquantitytKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabslipquantitytKeyReleased
       if(tabonceratet.getText().equals("")||tabslipquantityt.getText().equals("")||tabonceratet.getText().contains(" ")||tabslipquantityt.getText().contains(" "))
                tabslipratet.setText("");
            else
                    tabslipratet.setText(String.valueOf(Integer.valueOf(tabslipquantityt.getText())*Integer.valueOf(tabonceratet.getText())));
    }//GEN-LAST:event_tabslipquantitytKeyReleased

    private void medcancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medcancelActionPerformed
        meddefault();
    }//GEN-LAST:event_medcancelActionPerformed

    private void inhmgtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inhmgtActionPerformed

    }//GEN-LAST:event_inhmgtActionPerformed

    private void itmonceratetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmonceratetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itmonceratetActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new module1().setVisible(true);
        dispose();
    }//GEN-LAST:event_backActionPerformed

    private void tabaddtabletscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tabaddtabletscActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tabaddtabletscActionPerformed

    private void stotodaytableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stotodaytableMouseClicked
        if(stotodaymodel.getRowCount()<=0);
        else{
            stotodayviewmodel.setRowCount(0);
            int selected=stotodaytable.getSelectedRow();
            stocustidt.setText(stotodaymodel.getValueAt(selected,0).toString());
            stoempidt.setText(stotodaymodel.getValueAt(selected,1).toString());
            stocustmailidt.setText(stotodaymodel.getValueAt(selected,4).toString());
            stosalsedatet.setText(stotodaymodel.getValueAt(selected,6).toString());
            String sto=stotodaymodel.getValueAt(selected,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            for(int i=0;i<stoarray.length;i++){
                stotodayviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                i+=2;
            }
            stotodaytott.setText(stotodaymodel.getValueAt(selected,3).toString()); 
        }
    }//GEN-LAST:event_stotodaytableMouseClicked

    private void stosearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stosearchActionPerformed
        stosearchmodel.setRowCount(0);
        if(stosearchfromt.getDate()==null&&stosearchtot.getDate()==null){
            JOptionPane.showMessageDialog(this,"Atleast fill one date field. Do you wamt one day's record ? Fill from date field.");
        }
        else if(stosearchfromt.getDate()!=null&&stosearchtot.getDate()==null){
         
        try{
                java.util.Date datefrom=dcn.parse(dcn.format(stosearchfromt.getDate()));
                ResultSet df=stmt.executeQuery("select * from salseitem where purchasedate='"+dcn.format(stosearchfromt.getDate())+"'");
                while(df.next()){
                        stosearchmodel.addRow(new Object[]{df.getString(1),df.getString(2),df.getString(3),df.getString(4),df.getString(5),df.getString(6),df.getString(7)});
                }
                if(stosearchtable.getRowCount()==0);
                else{
                    String sto=stosearchmodel.getValueAt(0,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            stosearchviewmodel.setRowCount(0);
            for(int i=0;i<stoarray.length;i++){
                stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});              
                i+=2;
            }
                }
                int tot=0;
            for(int c=0;c<stosearchmodel.getRowCount();c++)
                tot+=Integer.valueOf(stosearchmodel.getValueAt(c,3).toString());
            stosearchtott.setText(String.valueOf(tot+"  "+"Rs"));
            } 
            catch(Exception z){
                System.out.println(z);
            }
        }
        else if(stosearchfromt.getDate()==null&&stosearchtot.getDate()!=null){
            JOptionPane.showMessageDialog(this,"Do you want one day's record ? Fill from date field.");
            stosearchtot.setCalendar(null);
        }
        else if(stosearchfromt.getDate()!=null&&stosearchtot.getDate()!=null){
            try{
                java.util.Date fromdate=dcn.parse(dcn.format(stosearchfromt.getDate()));
                java.util.Date todate=dcn.parse(dcn.format(stosearchtot.getDate()));
                if(fromdate.compareTo(todate)<0){
                    ResultSet rm=stmt.executeQuery("select * from salseitem");
                    java.util.Date compdate;
                    while(rm.next()){
                        String sdate=rm.getString(7);
                        compdate=dcn.parse(sdate);
                        if(fromdate.compareTo(compdate)<=0){
                            if(todate.compareTo(compdate)>=0){
                                stosearchmodel.addRow(new Object[]{rm.getString(1),rm.getString(2),rm.getString(3),rm.getString(4),rm.getString(5),rm.getString(6),rm.getString(7)});
                            }
                        }
                    }
                    if(stosearchtable.getRowCount()==0);
                else{
                    String sto=stosearchmodel.getValueAt(0,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            stosearchviewmodel.setRowCount(0);
            for(int i=0;i<stoarray.length;i++){
                stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});              
                i+=2;
            }
                }
                    int tot=0;
                    for(int c=0;c<stosearchmodel.getRowCount();c++)
                    tot+=Integer.valueOf(stosearchmodel.getValueAt(c,3).toString());
                    stosearchtott.setText(String.valueOf(tot+"  "+"Rs"));
                }
                else if(fromdate.compareTo(todate)==0){
                    JOptionPane.showMessageDialog(this,"From Date To Date both are same. change the To date field.");
                }
                else{
                   JOptionPane.showMessageDialog(this,"To Date field is lower than From date field. Change the order."); 
                }
            }
            catch(Exception p){
                System.out.println(p);
            }     
        }
    }//GEN-LAST:event_stosearchActionPerformed

    private void stotodaybActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stotodaybActionPerformed
        stocategory.setSelectedIndex(0);
    }//GEN-LAST:event_stotodaybActionPerformed

    private void stosearchbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stosearchbActionPerformed
        stocategory.setSelectedIndex(1);
    }//GEN-LAST:event_stosearchbActionPerformed

    private void stopendingbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopendingbActionPerformed
        stocategory.setSelectedIndex(2);
        stopendefault();
    }//GEN-LAST:event_stopendingbActionPerformed

    private void stopensearchtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopensearchtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stopensearchtActionPerformed

    private void stopenupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopenupdateActionPerformed
       try{
            if(stopenmedcategoryt.getText().equals("TABLETS")){
                if(stopentabactualt.getText().equals("0")){
                    JOptionPane.showMessageDialog(this,"ADD MEDICINES");
                    stopendefault();
                }
                else{    
                stmt.executeUpdate("update medicine set numofmedicines="+(Integer.valueOf(stopentabexistingt.getText())+Integer.valueOf(stopentabactualt.getText()))+",expireydate='"+dcn.format(stopentabexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+stopenmedidt.getText()+"' ");
                stopendefault();
                }
            }
       else{
             if(stopenothaddt.getText().equals("")){
                 JOptionPane.showMessageDialog(this,"ADD MEDICINES");
                    stopendefault();
             }   
             else{
                stmt.executeUpdate("update medicine set numofmedicines="+(Integer.valueOf(stopenothexistingt.getText())+Integer.valueOf(stopenothaddt.getText()))+",expireydate='"+dcn.format(stopenothexpireydatet.getDate())+"',lastupdate='"+java.time.LocalDate.now().toString()+"' where medid='"+stopenmedidt.getText()+"' "); 
                stopendefault();
             }
       }
       }
       catch(Exception j){
           System.out.println(j);
       }
    }//GEN-LAST:event_stopenupdateActionPerformed

    private void stopentabaddcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopentabaddcActionPerformed

    }//GEN-LAST:event_stopentabaddcActionPerformed

    private void stopenothaddtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopenothaddtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stopenothaddtActionPerformed

    private void stopentabaddtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopentabaddtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stopentabaddtActionPerformed

    private void stopentableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stopentableMouseClicked
       if(stopentablemodel.getRowCount()<=0);
       else{
        try{
           int selected=stopentable.getSelectedRow();
           if(stopentablemodel.getValueAt(selected,2).toString().equals("TABLETS")){
               stopencategory.setSelectedIndex(0);
               stopenmedidt.setText(stopentablemodel.getValueAt(selected, 0).toString());
               stopenmednamet.setText(stopentablemodel.getValueAt(selected, 1).toString());
               stopenmedcategoryt.setText(stopentablemodel.getValueAt(selected,2).toString());
               stopentabexistingt.setText(stopentablemodel.getValueAt(selected,8).toString());
               stopentabaddc.setSelectedIndex(0);
               stopentabaddt.setText("");
               stopentabactualt.setText("0");
               try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopentablemodel.getValueAt(selected, 9));
                    stopentabexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
           }
           else{
               stopencategory.setSelectedIndex(1);
                stopenmedidt.setText(stopentablemodel.getValueAt(selected,0).toString());
                stopenmednamet.setText(stopentablemodel.getValueAt(selected,1).toString());
                stopenmedcategoryt.setText(stopentablemodel.getValueAt(selected, 2).toString());
                stopenothexistingt.setText(stopentablemodel.getValueAt(selected,8).toString());
                stopenothaddt.setText("");
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopentablemodel.getValueAt(selected, 9));
                    stopenothexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
           }
       }
       catch(Exception j){
           System.out.println(j);
       }
      }
    }//GEN-LAST:event_stopentableMouseClicked

    private void stopensearchtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stopensearchtKeyReleased
        if(stopensearcht.getText().equals("")||stopensearcht.getText().contains(" "));
        else{
        try{
        ResultSet ry=stmt.executeQuery("select * from medicine where numofmedicines<=500 and medname like'"+stopensearcht.getText()+"%'");  
            while(ry.next())
                stopensearchmodel.addRow(new Object[]{ry.getString(1),ry.getString(2),ry.getString(3),ry.getString(4),ry.getString(5),ry.getString(6),ry.getString(7),ry.getString(8),ry.getString(9),ry.getString(10),ry.getString(11),ry.getString(12)});
        }
        catch(Exception j){
            System.out.println(j);
        }
        }
    }//GEN-LAST:event_stopensearchtKeyReleased

    private void stopensearchtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stopensearchtKeyTyped
         stopensearchmodel.setRowCount(0);
    }//GEN-LAST:event_stopensearchtKeyTyped

    private void stopensearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stopensearchtableMouseClicked
        if(stopensearchmodel.getRowCount()<=0);
        else{
        try{
           int selected=stopensearchtable.getSelectedRow();
           if(stopensearchmodel.getValueAt(selected,2).toString().equals("TABLETS")){
               stopencategory.setSelectedIndex(0);
               stopenmedidt.setText(stopensearchmodel.getValueAt(selected, 0).toString());
               stopenmednamet.setText(stopensearchmodel.getValueAt(selected, 1).toString());
               stopenmedcategoryt.setText(stopensearchmodel.getValueAt(selected,2).toString());
               stopentabexistingt.setText(stopensearchmodel.getValueAt(selected,8).toString());
               stopentabaddc.setSelectedIndex(0);
               stopentabaddt.setText("");
               stopentabactualt.setText("0");
               try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopensearchmodel.getValueAt(selected, 9));
                    stopentabexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
           }
           else{
               stopencategory.setSelectedIndex(1);
                stopenmedidt.setText(stopensearchmodel.getValueAt(selected,0).toString());
                stopenmednamet.setText(stopensearchmodel.getValueAt(selected,1).toString());
                stopenmedcategoryt.setText(stopensearchmodel.getValueAt(selected, 2).toString());
                stopenothexistingt.setText(stopensearchmodel.getValueAt(selected,8).toString());
                stopenothaddt.setText("");
                try{
                    java.util.Date date= new SimpleDateFormat("yyyy-MM-dd").parse((String)stopensearchmodel.getValueAt(selected, 9));
                    stopenothexpireydatet.setDate(date);
                }
                catch(Exception j){
                    System.out.println(j);
                }
           }
           stopensearchmodel.setRowCount(0);
           stopensearcht.setText("");
       }
       catch(Exception j){
           System.out.println(j);
       }
     }
    }//GEN-LAST:event_stopensearchtableMouseClicked

    private void stopentabaddcItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_stopentabaddcItemStateChanged
       if(stopentabaddt.getText().equals("")||stopentabaddt.getText().contains(" "))
            stopentabactualt.setText("0");
       else{
         if(stopentabaddc.getSelectedItem()=="TABLET")
             stopentabactualt.setText(stopentabaddt.getText());
         else{
             try {
                 int slipqu=0;
                 ResultSet rp=stmt.executeQuery("select slipquantity from medicine where medid='"+stopenmedidt.getText()+"'");
                 while(rp.next()){
                     slipqu=rp.getInt(1);
                 }
                 stopentabactualt.setText(String.valueOf(slipqu*Integer.valueOf(stopentabaddt.getText())));
             } catch (SQLException ex) {
                    System.out.println(ex);          }
         }
       }
    }//GEN-LAST:event_stopentabaddcItemStateChanged

    private void gotoempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gotoempActionPerformed
       servercategory.setSelectedIndex(0);
        empdefault();
    }//GEN-LAST:event_gotoempActionPerformed

    private void empphonetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empphonetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_empphonetActionPerformed

    private void empmailtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empmailtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_empmailtActionPerformed

    private void stopentabaddtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stopentabaddtKeyReleased
       if(stopentabaddt.getText().equals("")||stopentabaddt.getText().contains(" "))
            stopentabactualt.setText("0");
       else{
         if(stopentabaddc.getSelectedItem()=="TABLET")
             stopentabactualt.setText(stopentabaddt.getText());
         else{
             try {
                 int slipqu=0;
                 ResultSet rp=stmt.executeQuery("select slipquantity from medicine where medid='"+stopenmedidt.getText()+"'");
                 while(rp.next()){
                     slipqu=rp.getInt(1);
                 }
                 stopentabactualt.setText(String.valueOf(slipqu*Integer.valueOf(stopentabaddt.getText())));
             } catch (SQLException ex) {
                    System.out.println(ex);          }
         }
       }
    }//GEN-LAST:event_stopentabaddtKeyReleased

    private void liqnametActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_liqnametActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_liqnametActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if(stosearchmodel.getRowCount()<=0);
        else{
            try {
                stosearchtable.print();
            } catch (PrinterException ex) {
                Logger.getLogger(module2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            if(stotodaytable.getRowCount()<=0);
            else{
                stotodaytable.print();
            }
        }
        catch(Exception e){
            
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tabonceratetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabonceratetKeyTyped
         char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_tabonceratetKeyTyped

    private void tabslipquantitytKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabslipquantitytKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_tabslipquantitytKeyTyped

    private void tabslipratetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabslipratetKeyTyped
       char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_tabslipratetKeyTyped

    private void tabaddtabletstKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabaddtabletstKeyTyped
       char c=evt.getKeyChar();
       if((c>='0'&&c<='9')||c=='-');
       else
           evt.consume();
    }//GEN-LAST:event_tabaddtabletstKeyTyped

    private void liqmltKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_liqmltKeyTyped
       char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_liqmltKeyTyped

    private void liqonceratetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_liqonceratetKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_liqonceratetKeyTyped

    private void liqaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_liqaddtKeyTyped
       char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_liqaddtKeyTyped

    private void inhmgtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inhmgtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_inhmgtKeyTyped

    private void inhonceratetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inhonceratetKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_inhonceratetKeyTyped

    private void inhaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inhaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_inhaddtKeyTyped

    private void itmonceratetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itmonceratetKeyTyped
       char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_itmonceratetKeyTyped

    private void itmaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itmaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_itmaddtKeyTyped

    private void stopentabaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stopentabaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_stopentabaddtKeyTyped

    private void stopenothaddtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stopenothaddtKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_stopenothaddtKeyTyped

    private void empphonetKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_empphonetKeyTyped
        char c=evt.getKeyChar();
       if(c>='0'&&c<='9');
        else
           evt.consume();
    }//GEN-LAST:event_empphonetKeyTyped

    private void medaddcItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_medaddcItemStateChanged
        if(medaddc.getSelectedItem()=="TABLETS"){
            medservercategory.setSelectedIndex(0);
            tabletalignment1();
            medtabicon.setVisible(true);
            medliqicon.setVisible(false);
            medinhicon.setVisible(false);
            meditmicon.setVisible(false);
        }
        else if(medaddc.getSelectedItem()=="LIQUID"){
            medservercategory.setSelectedIndex(1);
            liquidalignment1();
             medtabicon.setVisible(false);
            medliqicon.setVisible(true);
            medinhicon.setVisible(false);
            meditmicon.setVisible(false);
        }
        else if(medaddc.getSelectedItem()=="INHALERS"){
            medservercategory.setSelectedIndex(2);
            inhaleralignment1();
            medtabicon.setVisible(false);
            medliqicon.setVisible(false);
            medinhicon.setVisible(true);
            meditmicon.setVisible(false);
        }
        else if(medaddc.getSelectedItem()=="OTHERS"){
            medservercategory.setSelectedIndex(3);
            otheralignment1();
            medtabicon.setVisible(false);
            medliqicon.setVisible(false);
            medinhicon.setVisible(false);
            meditmicon.setVisible(true);
        } 
    }//GEN-LAST:event_medaddcItemStateChanged

    private void stosearchtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stosearchtableMouseClicked
       if(stosearchmodel.getRowCount()<=0);
        else{
            stosearchviewmodel.setRowCount(0);
            int selected=stosearchtable.getSelectedRow();
            String sto=stosearchmodel.getValueAt(selected,2).toString();
            sto = sto.substring(1, sto.length() - 1);
            String []stoarray=sto.split(", ");
            for(int i=0;i<stoarray.length;i++){
                stosearchviewmodel.addRow(new Object[]{stoarray[i],stoarray[i+1],stoarray[i+2]});
                i+=2;
            }        
        }
    }//GEN-LAST:event_stosearchtableMouseClicked
  
    /**
     * @param args the command line arguments
     */
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton empadd;
    private javax.swing.JLabel empaddheadline;
    private javax.swing.JButton empcancel;
    private javax.swing.JButton empdelete;
    private javax.swing.JPanel empdetailpanel;
    private javax.swing.JTable empdetailtable;
    private javax.swing.JLabel empidl;
    private javax.swing.JLabel empidt;
    private javax.swing.JLabel empjoindatel;
    private javax.swing.JLabel empjoindatet;
    private javax.swing.JLabel emplastupdatel;
    private javax.swing.JLabel emplastupdatet;
    private javax.swing.JButton employeedetails;
    private javax.swing.JButton employeelist;
    private javax.swing.JLabel empmaill;
    private javax.swing.JTextField empmailt;
    private javax.swing.JLabel emppageheadline;
    private javax.swing.JPanel emppagepanel;
    private javax.swing.JLabel emppasswordl;
    private javax.swing.JTextField emppasswordt;
    private javax.swing.JLabel empphonel;
    private javax.swing.JTextField empphonet;
    private javax.swing.JButton empsave;
    private javax.swing.JLabel empsearchl;
    private javax.swing.JTextField empsearcht;
    private javax.swing.JTable empsearchtable;
    private javax.swing.JLabel empusernamel;
    private javax.swing.JTextField empusernamet;
    private javax.swing.JButton gotoemp;
    private javax.swing.JLabel inhaddl;
    private javax.swing.JTextField inhaddt;
    private javax.swing.JPanel inhalerspanel;
    private javax.swing.JLabel inhexistingl;
    private javax.swing.JLabel inhexistingt;
    private javax.swing.JLabel inhexpireydatel;
    private com.toedter.calendar.JDateChooser inhexpireydatet;
    private javax.swing.JLabel inhidl;
    private javax.swing.JLabel inhidt;
    private javax.swing.JLabel inhjoindatel;
    private javax.swing.JLabel inhjoindatet;
    private javax.swing.JLabel inhlastupdatel;
    private javax.swing.JLabel inhlastupdatet;
    private javax.swing.JLabel inhmgl;
    private javax.swing.JTextField inhmgt;
    private javax.swing.JLabel inhnamel;
    private javax.swing.JTextField inhnamet;
    private javax.swing.JLabel inhonceratel;
    private javax.swing.JTextField inhonceratet;
    private javax.swing.JLabel itmaddl;
    private javax.swing.JTextField itmaddt;
    private javax.swing.JLabel itmexistingl;
    private javax.swing.JLabel itmexistingt;
    private javax.swing.JLabel itmexpireydatel;
    private com.toedter.calendar.JDateChooser itmexpireydatet;
    private javax.swing.JLabel itmidl;
    private javax.swing.JLabel itmidt;
    private javax.swing.JLabel itmjoindatel;
    private javax.swing.JLabel itmjoindatet;
    private javax.swing.JLabel itmlastupdatel;
    private javax.swing.JLabel itmlastupdatet;
    private javax.swing.JLabel itmnamel;
    private javax.swing.JTextField itmnamet;
    private javax.swing.JLabel itmonceratel;
    private javax.swing.JTextField itmonceratet;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jsp1;
    private javax.swing.JLabel liqaddl;
    private javax.swing.JTextField liqaddt;
    private javax.swing.JLabel liqexistingliquidl;
    private javax.swing.JLabel liqexistingliquidt;
    private javax.swing.JLabel liqexpireydatel;
    private com.toedter.calendar.JDateChooser liqexpireydatet;
    private javax.swing.JLabel liqidl;
    private javax.swing.JLabel liqidt;
    private javax.swing.JLabel liqjoindatel;
    private javax.swing.JLabel liqjoindatet;
    private javax.swing.JLabel liqlastupdatel;
    private javax.swing.JLabel liqlastupdatet;
    private javax.swing.JLabel liqmll;
    private javax.swing.JTextField liqmlt;
    private javax.swing.JLabel liqnamel;
    private javax.swing.JTextField liqnamet;
    private javax.swing.JLabel liqonceratel;
    private javax.swing.JTextField liqonceratet;
    private javax.swing.JPanel liquidpanel;
    private javax.swing.JButton medadd;
    private javax.swing.JComboBox<String> medaddc;
    private javax.swing.JButton medcancel;
    private javax.swing.JButton meddelete;
    private javax.swing.JPanel meddetailspage;
    private javax.swing.JTable meddetailtable;
    private javax.swing.JButton medgotomed;
    private javax.swing.JLabel medheadline;
    private javax.swing.JButton medicinedetails;
    private javax.swing.JButton medicinelist;
    private javax.swing.JLabel medicinepageheadline;
    private javax.swing.JLabel medinhicon;
    private javax.swing.JLabel meditmicon;
    private javax.swing.JScrollPane medjsp1;
    private javax.swing.JLabel medliqicon;
    private javax.swing.JPanel medpagepanel;
    private javax.swing.JButton medsave;
    private javax.swing.JTextField medsearcht;
    private javax.swing.JTable medsearchtable;
    private javax.swing.JTabbedPane medservercategory;
    private javax.swing.JLabel medtabicon;
    private javax.swing.JPanel otherpanel;
    private javax.swing.JTabbedPane servercategory;
    private javax.swing.JTabbedPane stocategory;
    private javax.swing.JButton stockdetails;
    private javax.swing.JPanel stockspage;
    private javax.swing.JLabel stocustidt;
    private javax.swing.JLabel stocustmailidt;
    private javax.swing.JLabel stoempidt;
    private javax.swing.JTabbedPane stopencategory;
    private javax.swing.JLabel stopencategoryl;
    private javax.swing.JButton stopendingb;
    private javax.swing.JPanel stopendingpanel;
    private javax.swing.JLabel stopenmedcategoryt;
    private javax.swing.JLabel stopenmedidl;
    private javax.swing.JLabel stopenmedidt;
    private javax.swing.JLabel stopenmednamel;
    private javax.swing.JLabel stopenmednamet;
    private javax.swing.JLabel stopenothaddl;
    private javax.swing.JTextField stopenothaddt;
    private javax.swing.JPanel stopenotherpanel;
    private javax.swing.JLabel stopenothexistingl;
    private javax.swing.JLabel stopenothexistingt;
    private javax.swing.JLabel stopenothexpireydatel;
    private com.toedter.calendar.JDateChooser stopenothexpireydatet;
    private javax.swing.JTextField stopensearcht;
    private javax.swing.JTable stopensearchtable;
    private javax.swing.JLabel stopentabactuall;
    private javax.swing.JLabel stopentabactualt;
    private javax.swing.JComboBox<String> stopentabaddc;
    private javax.swing.JLabel stopentabaddl;
    private javax.swing.JTextField stopentabaddt;
    private javax.swing.JLabel stopentabexistingl;
    private javax.swing.JLabel stopentabexistingt;
    private com.toedter.calendar.JDateChooser stopentabexpireydatet;
    private javax.swing.JLabel stopentabexpireyl;
    private javax.swing.JTable stopentable;
    private javax.swing.JPanel stopentabpanel;
    private javax.swing.JButton stopenupdate;
    private javax.swing.JLabel stosalsedatet;
    private javax.swing.JButton stosearch;
    private javax.swing.JButton stosearchb;
    private com.toedter.calendar.JDateChooser stosearchfromt;
    private javax.swing.JPanel stosearchpanel;
    private javax.swing.JTable stosearchtable;
    private com.toedter.calendar.JDateChooser stosearchtot;
    private javax.swing.JLabel stosearchtott;
    private javax.swing.JTable stosearchviewtable;
    private javax.swing.JButton stotodayb;
    private javax.swing.JPanel stotodaypanel;
    private javax.swing.JTable stotodaytable;
    private javax.swing.JLabel stotodaytott;
    private javax.swing.JTable stotodayviewtable;
    private javax.swing.JLabel tabactualtabletsl;
    private javax.swing.JLabel tabactualtabletst;
    private javax.swing.JComboBox<String> tabaddtabletsc;
    private javax.swing.JLabel tabaddtabletsl;
    private javax.swing.JTextField tabaddtabletst;
    private javax.swing.JLabel tabexistingtabletsl;
    private javax.swing.JLabel tabexistingtabletst;
    private javax.swing.JLabel tabexpireydatel;
    private com.toedter.calendar.JDateChooser tabexpireydatet;
    private javax.swing.JLabel tabidl;
    private javax.swing.JLabel tabidt;
    private javax.swing.JLabel tabjoindatel;
    private javax.swing.JLabel tabjoindatet;
    private javax.swing.JLabel tablastupdatel;
    private javax.swing.JLabel tablastupdatet;
    private javax.swing.JPanel tabletpanel;
    private javax.swing.JLabel tabnamel;
    private javax.swing.JTextField tabnamet;
    private javax.swing.JLabel tabonceratel;
    private javax.swing.JTextField tabonceratet;
    private javax.swing.JLabel tabslipquantityl;
    private javax.swing.JTextField tabslipquantityt;
    private javax.swing.JLabel tabslipratel;
    private javax.swing.JTextField tabslipratet;
    // End of variables declaration//GEN-END:variables

}
